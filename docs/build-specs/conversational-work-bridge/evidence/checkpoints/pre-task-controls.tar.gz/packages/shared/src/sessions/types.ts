/**
 * Session Types
 *
 * Types for workspace-scoped sessions.
 * Sessions are stored at {workspaceRootPath}/sessions/{id}/session.jsonl
 *
 * JSONL Format:
 * - Line 1: SessionHeader (metadata + pre-computed fields for fast list loading)
 * - Lines 2+: StoredMessage (one message per line)
 */

import type { PermissionMode } from '../agent/mode-manager.ts';
import type { ThinkingLevel } from '../agent/thinking-levels.ts';
import type { StoredAttachment, MessageRole, ToolStatus, AuthRequestType, AuthStatus, CredentialInputMode, StoredMessage } from '@craft-agent/core/types';
import type { ChatGoalState } from './chat-goal.ts';
import type { SessionTaskList } from './session-tasks.ts';

/**
 * Session fields that persist to disk.
 * Add new fields here - they automatically propagate to JSONL read/write
 * via pickSessionFields() utility.
 *
 * IMPORTANT: When adding a new field:
 * 1. Add it to this array
 * 2. Add it to SessionConfig interface below
 * 3. Done - serialization is automatic
 */
export const SESSION_PERSISTENT_FIELDS = [
  // Identity
  'id', 'workspaceRootPath', 'sdkSessionId', 'sdkCwd',
  // Timestamps
  'createdAt', 'lastUsedAt', 'lastMessageAt',
  // Display
  'name', 'isFlagged', 'sessionStatus', 'labels', 'hidden',
  // Read tracking
  'lastReadMessageId', 'hasUnread',
  // Config
  'enabledSourceSlugs', 'permissionMode', 'previousPermissionMode', 'workingDirectory',
  'customSystemPrompt', 'agentSkillSlugs', 'trustedWorkerTools', 'managedSkillRunId', 'managedSkillRunLegacyReferences', 'legacySkillReferences',
  // Model/Connection
  'model', 'llmConnection', 'connectionLocked', 'thinkingLevel', 'modelFallbackRole',
  // Sharing
  'sharedUrl', 'sharedId',
  // Plan execution
  'pendingPlanExecution',
  // Chat-native Goal Mode
  'chatGoal',
  // Provider-neutral session task list
  'sessionTasks',
  // Archive
  'isArchived', 'archivedAt',
  // Branching
  'branchFromMessageId',
  'branchFromSdkSessionId',
  'branchFromSessionPath',
  'branchFromSdkCwd',
  'branchFromSdkTurnId',
  // Remote transfer handoff
  'transferredSessionSummary',
  'transferredSessionSummaryApplied',
  // Automation origin
  'triggeredBy',
  // Saved Agent origin
  'spawnedFromAgent',
  // Execution receipt
  'launchReceipt',
] as const;

export type SessionPersistentField = typeof SESSION_PERSISTENT_FIELDS[number];

/**
 * Session status (user-controlled, never automatic)
 *
 * Dynamic status ID referencing workspace status config.
 * Validated at runtime via validateSessionStatus().
 * Falls back to 'todo' if status doesn't exist.
 */
export type SessionStatus = string;

/**
 * Built-in status IDs (for TypeScript consumers)
 * These are the default statuses but users can add/remove custom ones
 */
export type BuiltInStatusId = 'todo' | 'in-progress' | 'needs-review' | 'done' | 'cancelled';

/**
 * Session token usage tracking
 */
export interface SessionTokenUsage {
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  contextTokens: number;
  costUsd: number;
  cacheReadTokens?: number;
  cacheCreationTokens?: number;
  /** Model's context window size in tokens (from SDK modelUsage) */
  contextWindow?: number;
}

export interface AgentCapabilityExpansionReceipt {
  skillSlug: string;
  contentRevision: string;
  taskModeId: string;
  taskModeRevision: string;
  inputMessageId: string;
  reason: string;
  loadedAt: number;
}

export interface SessionLaunchReceipt {
  /** Immutable host correlation and restrictive voice origin, retained on descendants. */
  voiceTask?: import('../agent-messaging/types.ts').VoiceTaskCorrelation & { receiptId: string };
  createdAt: number;
  origin: 'manual' | 'agent' | 'concierge' | 'workflow' | 'deep-research' | 'automation' | 'branch' | 'spawned-session';
  /** Immutable ancestry marker for sessions descended from background execution. */
  automatedAncestry?: boolean;
  /** Host-stamped provenance for an agent-delegated child session. */
  delegation?: {
    parentSessionId?: string;
    mechanism: 'spawn-session' | 'message-agent';
    depth: number;
  };
  summary?: string;
  agent?: {
    slug: string;
    name: string;
    description?: string;
    inputs?: string;
    outputs?: string;
    tags?: string[];
  };
  /** Host-owned adjacent-capability deliveries, retained across mode changes. */
  capabilityExpansions?: AgentCapabilityExpansionReceipt[];
  /** Current focused recipe selected by the user or launch route. */
  taskMode?: {
    schemaVersion: 1;
    id: string;
    label: string;
    definitionRevision: string;
    selectionSource: 'user' | 'manager' | 'workflow' | 'automation' | 'handoff' | 'legacy';
    primarySkills: string[];
    adjacentSkills: Array<{ slug: string; when: string; expansion: 'same-session' | 'new-session' | 'delegate' }>;
    fullMode: boolean;
  };
  /** The chat must receive a user-selected task mode before its first turn can begin. */
  taskModeSelectionPending?: boolean;
  workflow?: {
    runId?: string;
    slug: string;
    stepId?: string;
    maxAgentMessages?: number;
  };
  deepResearch?: {
    runId?: string;
    stepId?: string;
  };
  automation?: {
    name?: string;
    event?: string;
  };
  scheduledWork?: {
    id: string;
  };
  config: {
    model?: string;
    llmConnection?: string;
    permissionMode?: PermissionMode;
    thinkingLevel?: ThinkingLevel;
    workingDirectory?: string;
  };
  injected: {
    systemPromptChars?: number;
    skills: string[];
    sources: string[];
    trustedWorkerTools?: string[];
    contextDocs: Array<{ slug: string; name: string }>;
    managerBrief?: {
      revision: string;
      generatedAt: string;
      sourceHealth: Array<{ source: string; status: string }>;
    };
    agentCatalog?: Array<{
      slug: string;
      name: string;
      description?: string;
      inputs?: string;
      outputs?: string;
      tags?: string[];
    }>;
    /**
     * Memory entries injected into the system prompt. Names only — bodies
     * are not duplicated into the receipt to keep it small.
     */
    memory?: {
      user: Array<{ name: string }>;
      agent: Array<{ name: string }>;
    };
  };
  routing?: {
    mode: 'concierge';
    activeAgentCount: number;
    instruction: string;
  };
}

/**
 * Stored message format (simplified for persistence)
 * Re-exported from @craft-agent/core for convenience
 */
export type { StoredMessage } from '@craft-agent/core/types';

/**
 * Session configuration (persisted metadata)
 */
export interface SessionConfig {
  id: string;
  /** SDK session ID (captured after first message) */
  sdkSessionId?: string;
  /** Workspace root path this session belongs to */
  workspaceRootPath: string;
  /** Optional user-defined name */
  name?: string;
  createdAt: number;
  lastUsedAt: number;
  /** Timestamp of last meaningful message (user or final assistant). Used for date grouping in session list.
   *  Separate from lastUsedAt which tracks any session access (auto-save, open to read, etc.). */
  lastMessageAt?: number;
  /** Whether this session is flagged */
  isFlagged?: boolean;
  /** Permission mode for this session ('safe', 'ask', 'allow-all') */
  permissionMode?: PermissionMode;
  /** Previous permission mode (used to preserve modeTransition context across restarts) */
  previousPermissionMode?: PermissionMode;
  /** User-controlled session status - determines inbox vs completed */
  sessionStatus?: SessionStatus;
  /** Labels applied to this session (bare IDs or "id::value" entries) */
  labels?: string[];
  /** ID of last message user has read */
  lastReadMessageId?: string;
  /**
   * Explicit unread flag - single source of truth for NEW badge.
   * Set to true when assistant message completes while user is NOT viewing.
   * Set to false when user views the session (and not processing).
   */
  hasUnread?: boolean;
  /** Per-session source selection (source slugs) */
  enabledSourceSlugs?: string[];
  /** Working directory for this session (used by agent for bash commands and context) */
  workingDirectory?: string;
  /** SDK cwd for session storage - set once at creation, never changes. Ensures SDK can find session transcripts regardless of workingDirectory changes. */
  sdkCwd?: string;
  /** Shared viewer URL (if shared via viewer) */
  sharedUrl?: string;
  /** Shared session ID in viewer (for revoke) */
  sharedId?: string;
  /** Model to use for this session (overrides global config if set) */
  model?: string;
  /** LLM connection slug for this session (locked after first message) */
  llmConnection?: string;
  /** Whether the connection is locked (cannot be changed after first agent creation) */
  connectionLocked?: boolean;
  /** Thinking level for this session ('off', 'think', 'max') */
  thinkingLevel?: ThinkingLevel;
  modelFallbackRole?: 'reasoning' | 'fast';
  /** Full custom persona prompt appended to the backend system prompt. */
  customSystemPrompt?: string;
  /** Saved Agent skills applied implicitly to every turn in this session. */
  agentSkillSlugs?: string[];
  /** Latest admitted run; retries restore its exact private skill snapshot. */
  managedSkillRunId?: string;
  /** Frozen per-run choice; an empty array keeps fresh input current on retries. */
  managedSkillRunLegacyReferences?: string[];
  /** Pre-migration bare references, remapped only when replaying old input. */
  legacySkillReferences?: string[];
  /** Session tool names preauthorized for this trusted worker session. */
  trustedWorkerTools?: string[];
  /**
   * Pending plan execution state - tracks "Accept & Compact" flow.
   * When set, indicates a plan needs to be executed after compaction completes.
   * Cleared on: successful execution, new user message, or manual clear.
   */
  pendingPlanExecution?: {
    /** Path to the plan file to execute */
    planPath: string;
    /** Optional snapshot of draft input captured at accept time */
    draftInputSnapshot?: string;
    /** Whether we're still waiting for compaction to complete */
    awaitingCompaction: boolean;
    /** Whether execution has already been dispatched from the UI. */
    executionDispatched?: boolean;
  };
  /** Current or most recent chat-native Goal. Terminal history lives in session messages. */
  chatGoal?: ChatGoalState;
  /** Durable provider-neutral task list projected by session tools/adapters. */
  sessionTasks?: SessionTaskList;
  /** When true, session is hidden from session list (e.g., mini edit sessions) */
  hidden?: boolean;
  /** Whether this session is archived */
  isArchived?: boolean;
  /** Timestamp when session was archived (for retention policy) */
  archivedAt?: number;
  /**
   * Message ID this session was branched from.
   * Branching semantics are a hard cutoff: model context must not include parent messages after this message.
   */
  branchFromMessageId?: string;
  /**
   * Parent session's SDK session ID (optional, only for provider strategies that support strict SDK-level forking).
   */
  branchFromSdkSessionId?: string;
  /**
   * Parent session's storage path (optional, only when provider-level forking needs parent session files).
   */
  branchFromSessionPath?: string;
  /**
   * Parent session's sdkCwd (optional). SDK session files are stored per-CWD
   * (`~/.claude/projects/{cwd-hash}/`), so forking requires the child subprocess
   * to use the parent's CWD to locate the parent's session file.
   */
  branchFromSdkCwd?: string;
  /**
   * Provider-native branch anchor at the branch point.
   * - Claude: assistant message UUID (used as `resumeSessionAt`)
   * - Pi: session entry ID (used with SessionManager.branch(anchor))
   */
  branchFromSdkTurnId?: string;
  /** One-shot hidden summary injected on the first turn after a remote transfer. */
  transferredSessionSummary?: string;
  /** Whether the transferred-session summary has already been injected. */
  transferredSessionSummaryApplied?: boolean;
  /** Metadata for sessions created by automations */
  triggeredBy?: { automationId?: string; automationName?: string; event?: string; timestamp?: number };
  /**
   * Provenance for sessions spawned by summoning a saved Agent.
   * Set at session-creation time; never updated thereafter.
   * The middle pane in the Agents navigator filters sessions by this field
   * so each agent becomes its own work-stream.
   */
  spawnedFromAgent?: { agentSlug: string; agentName: string; timestamp?: number };
  launchReceipt?: SessionLaunchReceipt;
}

/**
 * Stored session with conversation data
 */
export interface StoredSession extends SessionConfig {
  messages: StoredMessage[];
  tokenUsage: SessionTokenUsage;
}

/**
 * Session header - line 1 of session.jsonl
 *
 * Contains all metadata needed for list views (pre-computed at save time).
 * This enables fast session listing without parsing message content.
 */
export interface SessionHeader {
  id: string;
  /** SDK session ID (captured after first message) */
  sdkSessionId?: string;
  /** Workspace root path (stored as portable path, e.g., ~/.craft-agent/...) */
  workspaceRootPath: string;
  /** Optional user-defined name */
  name?: string;
  createdAt: number;
  lastUsedAt: number;
  /** Timestamp of last meaningful message — persisted separately from lastUsedAt for stable date grouping across restarts. */
  lastMessageAt?: number;
  /** Whether this session is flagged */
  isFlagged?: boolean;
  /** Permission mode for this session ('safe', 'ask', 'allow-all') */
  permissionMode?: PermissionMode;
  /** Previous permission mode (used to preserve modeTransition context across restarts) */
  previousPermissionMode?: PermissionMode;
  /** User-controlled session status - determines inbox vs completed */
  sessionStatus?: SessionStatus;
  /** Labels applied to this session (bare IDs or "id::value" entries) */
  labels?: string[];
  /** ID of last message user has read */
  lastReadMessageId?: string;
  /**
   * Explicit unread flag - single source of truth for NEW badge.
   * Set to true when assistant message completes while user is NOT viewing.
   * Set to false when user views the session (and not processing).
   */
  hasUnread?: boolean;
  /** Per-session source selection (source slugs) */
  enabledSourceSlugs?: string[];
  /** Working directory for this session (used by agent for bash commands and context) */
  workingDirectory?: string;
  /** SDK cwd for session storage - set once at creation, never changes */
  sdkCwd?: string;
  /** Shared viewer URL (if shared via viewer) */
  sharedUrl?: string;
  /** Shared session ID in viewer (for revoke) */
  sharedId?: string;
  /** Model to use for this session (overrides global config if set) */
  model?: string;
  /** LLM connection slug for this session (locked after first message) */
  llmConnection?: string;
  /** Whether the connection is locked (cannot be changed after first agent creation) */
  connectionLocked?: boolean;
  /** Thinking level for this session ('off', 'think', 'max') */
  thinkingLevel?: ThinkingLevel;
  modelFallbackRole?: 'reasoning' | 'fast';
  /** Full custom persona prompt appended to the backend system prompt. */
  customSystemPrompt?: string;
  /** Saved Agent skills applied implicitly to every turn in this session. */
  agentSkillSlugs?: string[];
  /** Latest admitted run; retries restore its exact private skill snapshot. */
  managedSkillRunId?: string;
  /** Frozen per-run choice; an empty array keeps fresh input current on retries. */
  managedSkillRunLegacyReferences?: string[];
  /** Pre-migration bare references, remapped only when replaying old input. */
  legacySkillReferences?: string[];
  /** Session tool names preauthorized for this trusted worker session. */
  trustedWorkerTools?: string[];
  /**
   * Pending plan execution state - tracks "Accept & Compact" flow.
   * When set, indicates a plan needs to be executed after compaction completes.
   * Cleared on: successful execution, new user message, or manual clear.
   */
  pendingPlanExecution?: {
    /** Path to the plan file to execute */
    planPath: string;
    /** Optional snapshot of draft input captured at accept time */
    draftInputSnapshot?: string;
    /** Whether we're still waiting for compaction to complete */
    awaitingCompaction: boolean;
    /** Whether execution has already been dispatched from the UI. */
    executionDispatched?: boolean;
  };
  /** Current or most recent chat-native Goal. */
  chatGoal?: ChatGoalState;
  /** Durable provider-neutral task list. */
  sessionTasks?: SessionTaskList;
  /** When true, session is hidden from session list (e.g., mini edit sessions) */
  hidden?: boolean;
  /** Whether this session is archived */
  isArchived?: boolean;
  /** Timestamp when session was archived (for retention policy) */
  archivedAt?: number;
  /** One-shot hidden summary injected on the first turn after a remote transfer. */
  transferredSessionSummary?: string;
  /** Whether the transferred-session summary has already been injected. */
  transferredSessionSummaryApplied?: boolean;
  /** Metadata for sessions created by automations */
  triggeredBy?: { automationId?: string; automationName?: string; event?: string; timestamp?: number };
  /**
   * Provenance for sessions spawned by summoning a saved Agent.
   * Set at session-creation time; never updated thereafter.
   * The middle pane in the Agents navigator filters sessions by this field
   * so each agent becomes its own work-stream.
   */
  spawnedFromAgent?: { agentSlug: string; agentName: string; timestamp?: number };
  launchReceipt?: SessionLaunchReceipt;
  // Pre-computed fields for fast list loading
  /** Number of messages in session */
  messageCount: number;
  /** Role/type of the last message (for badge display without loading messages) */
  lastMessageRole?: 'user' | 'assistant' | 'plan' | 'tool' | 'error';
  /** Preview of first user message (first 150 chars) */
  preview?: string;
  /** Token usage statistics */
  tokenUsage: SessionTokenUsage;
  /** ID of the last final (non-intermediate) assistant message - for unread detection without loading messages */
  lastFinalMessageId?: string;
}

/**
 * Session metadata (lightweight, for lists)
 */
export interface SessionMetadata {
  id: string;
  workspaceRootPath: string;
  name?: string;
  createdAt: number;
  lastUsedAt: number;
  /** Timestamp of last meaningful message — used for date grouping. Falls back to lastUsedAt for pre-fix sessions. */
  lastMessageAt?: number;
  messageCount: number;
  /** Preview of first user message */
  preview?: string;
  sdkSessionId?: string;
  /** Whether this session is flagged */
  isFlagged?: boolean;
  /** User-controlled session status */
  sessionStatus?: SessionStatus;
  /** Labels applied to this session (bare IDs or "id::value" entries) */
  labels?: string[];
  /** Permission mode for this session */
  permissionMode?: PermissionMode;
  /** Previous permission mode (used to preserve modeTransition context across restarts) */
  previousPermissionMode?: PermissionMode;
  /** Number of plan files for this session */
  planCount?: number;
  /** Shared viewer URL (if shared via viewer) */
  sharedUrl?: string;
  /** Shared session ID in viewer (for revoke) */
  sharedId?: string;
  /** Working directory for this session */
  workingDirectory?: string;
  /** SDK cwd for session storage - set once at creation, never changes */
  sdkCwd?: string;
  /** Role/type of the last message (for badge display without loading messages) */
  lastMessageRole?: 'user' | 'assistant' | 'plan' | 'tool' | 'error';
  /** Model to use for this session (overrides global config if set) */
  model?: string;
  /** LLM connection slug for this session (locked after first message) */
  llmConnection?: string;
  /** Whether the connection is locked (cannot be changed after first agent creation) */
  connectionLocked?: boolean;
  /** Thinking level for this session ('off', 'think', 'max') */
  thinkingLevel?: ThinkingLevel;
  modelFallbackRole?: 'reasoning' | 'fast';
  /** Current or most recent chat-native Goal. */
  chatGoal?: ChatGoalState;
  /** Durable provider-neutral task list. */
  sessionTasks?: SessionTaskList;
  /** ID of last message user has read - for unread detection */
  lastReadMessageId?: string;
  /** ID of the last final (non-intermediate) assistant message - for unread detection */
  lastFinalMessageId?: string;
  /**
   * Explicit unread flag - single source of truth for NEW badge.
   * Set to true when assistant message completes while user is NOT viewing.
   * Set to false when user views the session (and not processing).
   */
  hasUnread?: boolean;
  /** Token usage statistics (from JSONL header, available without loading messages) */
  tokenUsage?: SessionTokenUsage;
  /** When true, session is hidden from session list (e.g., mini edit sessions) */
  hidden?: boolean;
  /** Whether this session is archived */
  isArchived?: boolean;
  /** Timestamp when session was archived (for retention policy) */
  archivedAt?: number;
  /** Message ID that this session was branched from (hard context cutoff marker). */
  branchFromMessageId?: string;
  /** Provenance for sessions spawned by summoning a saved Agent. */
  spawnedFromAgent?: { agentSlug: string; agentName: string; timestamp?: number };
  launchReceipt?: SessionLaunchReceipt;
}
