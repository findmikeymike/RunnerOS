import { randomUUID } from 'node:crypto';
import type { CreateSessionOptions } from '@craft-agent/shared/protocol';
import {
  DEFAULT_MAX_DEPTH,
  listAgentMessageReceipts,
  normalizeMessageAgentInput,
  isPermissionEscalation,
  writeAgentMessageReceipt,
  type AgentMessageReceipt,
  type VoiceTaskCorrelation,
  type AgentMessageTerminalOutcome,
  type MessageAgentInput,
  type MessageAgentResult,
} from '@craft-agent/shared/agent-messaging';
import {
  appendOutputSchemaInstruction,
  parseStructuredStepOutput,
} from '@craft-agent/shared/workflows';
import type { PermissionMode } from '@craft-agent/shared/agent/mode-types';
import type { AgentMessageNoticeMetadata } from '@craft-agent/core/types';

export interface AgentMessageRuntimeContext {
  voiceTask?: VoiceTaskCorrelation;
  workspaceId: string;
  parentSessionId?: string;
  parentRunId?: string;
  parentStepId?: string;
  workflowSlug?: string;
  callerAgentSlug?: string;
  callerAgentName?: string;
  parentPermissionMode: PermissionMode;
  automatedAncestry?: boolean;
  depth?: number;
  maxDepth?: number;
  maxAgentMessages?: number;
}

export interface AgentMessageServiceDeps {
  executeVoiceTurn?: (sessionId: string, prompt: string, options?: { skillSlugs?: string[]; displayIntent?: 'agent-delegation-task' }) => Promise<AgentMessageTerminalOutcome>;
  assertVoiceBackendSupported?: (workspaceId: string, options: Partial<CreateSessionOptions>) => void;
  onReceiptChanged?: (receipt: AgentMessageReceipt) => void;
  createSession: (workspaceId: string, options: CreateSessionOptions) => Promise<{ id: string }>;
  resolveAgentSessionOptions: (
    workspaceId: string,
    agentSlug: string,
    options?: { taskModeId?: string; taskModeSelectionSource?: 'handoff' },
  ) => Promise<Partial<CreateSessionOptions>>;
  sendMessage: (sessionId: string, prompt: string, options?: {
    skillSlugs?: string[];
    displayIntent?: 'agent-delegation-task';
  }) => Promise<void>;
  abortSession: (sessionId: string) => Promise<void>;
  getLastAssistantText: (sessionId: string) => string;
  getSessionToolUseSummary: (sessionId: string) => { count: number; names: string[] };
  getWorkspaceRootPath: (workspaceId: string) => string;
  resolveUsableSourceSlugs?: (workspaceId: string, sourceSlugs: string[]) => { usable: string[]; unavailable: string[] };
  /** Whether the target agent is activated in this workspace. */
  isAgentActive?: (workspaceId: string, agentSlug: string) => boolean;
  deliverPassiveMessage?: (sessionId: string, message: string, agentMessage?: AgentMessageNoticeMetadata) => Promise<void>;
  now?: () => string;
}

function summaryFromOutput(output: unknown): string {
  const text = typeof output === 'string' ? output : JSON.stringify(output);
  return (text ?? '').trim().replace(/\s+/g, ' ').slice(0, 1000);
}

function buildDelegationPrompt(
  input: ReturnType<typeof normalizeMessageAgentInput>,
  runtime: Pick<AgentMessageRuntimeContext, 'callerAgentSlug' | 'parentSessionId'>,
): string {
  const parts = [
    'You are executing a delegated RunnerOS agent message.',
    '',
    `Delegating agent: ${runtime.callerAgentSlug ?? 'session'}`,
    `Target agent: ${input.agentSlug}`,
  ];

  if (runtime.parentSessionId) {
    parts.push(
      `Parent session ID: ${runtime.parentSessionId}`,
      '',
      `If you need to send an important progress update, blocker, or clarification back before your final result, use send_agent_message with sessionId "${runtime.parentSessionId}" and deliveryMode "passive".`,
      'Still return the requested final result in this delegated session.',
    );
  }

  parts.push('', 'Task:', input.task);

  if (input.context) {
    parts.push('', 'Context:', input.context);
  }
  if (input.expectedOutput) {
    parts.push('', 'Expected output:', input.expectedOutput);
  }
  if (input.sourceSlugs.length > 0) {
    parts.push('', `Allowed source slugs: ${input.sourceSlugs.join(', ')}`);
  }
  if (input.skillSlugs.length > 0) {
    parts.push('', `Requested skill slugs: ${input.skillSlugs.join(', ')}`);
  }

  parts.push(
    '',
    'Return only the requested result. Do not ask the user follow-up questions unless the task is impossible without them.',
  );

  const prompt = parts.join('\n');
  return input.outputSchema ? appendOutputSchemaInstruction(prompt, input.outputSchema) : prompt;
}

function timeout<T>(promise: Promise<T>, ms: number): Promise<{ timedOut: false; value: T } | { timedOut: true }> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => resolve({ timedOut: true }), ms);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve({ timedOut: false, value });
      },
      (error) => {
        clearTimeout(timer);
        reject(error);
      },
    );
  });
}

const delegationMutexes = new Map<string, Promise<void>>();

function withDelegationMutex<T>(key: string, fn: () => Promise<T> | T): Promise<T> {
  const previous = delegationMutexes.get(key) ?? Promise.resolve();
  const next = previous.then(fn, fn);
  delegationMutexes.set(key, next.then(() => {}, () => {}));
  return next;
}

async function drainAfterAbort<T>(promise: Promise<T>, ms = 5000): Promise<void> {
  try {
    await timeout(promise, ms);
  } catch {
    // The receipt already records the timeout. Draining only prevents a late
    // rejection from escaping after the child session has been aborted.
  }
}

export class AgentMessageService {
  constructor(private readonly deps: AgentMessageServiceDeps) {}

  async messageAgent(
    runtime: AgentMessageRuntimeContext,
    rawInput: MessageAgentInput,
  ): Promise<MessageAgentResult> {
    const depth = runtime.depth ?? 0;
    const maxDepth = runtime.maxDepth ?? DEFAULT_MAX_DEPTH;
    const input = normalizeMessageAgentInput(rawInput, {
      parentPermissionMode: runtime.parentPermissionMode,
      depth,
      maxDepth,
    });
    const now = this.deps.now ?? (() => new Date().toISOString());
    const createdAt = now();
    const receipt: AgentMessageReceipt = {
      schemaVersion: 1,
      ...(runtime.voiceTask ? { voiceTask: runtime.voiceTask } : {}),
      id: randomUUID(),
      workspaceId: runtime.workspaceId,
      parentSessionId: runtime.parentSessionId,
      parentRunId: runtime.parentRunId,
      parentStepId: runtime.parentStepId,
      callerAgentSlug: runtime.callerAgentSlug,
      targetAgentSlug: input.agentSlug,
      task: input.task,
      status: 'running',
      policy: {
        permissionMode: input.permissionMode,
        timeoutSeconds: input.timeoutSeconds,
        maxTurns: input.maxTurns,
        maxDepth,
        depth,
        maxAgentMessages: runtime.maxAgentMessages,
        background: input.background,
      },
      constraints: {
        ...(input.taskModeId ? { taskModeId: input.taskModeId } : {}),
        sourceSlugs: input.sourceSlugs,
        skillSlugs: input.skillSlugs,
        outputSchema: input.outputSchema,
      },
      createdAt,
      updatedAt: createdAt,
    };

    // Two rules the system prompt states but nothing enforced. The spawn-depth
    // gate stops runaway recursion; it does not stop A -> A, and nothing stopped
    // routing work to a worker that is not active here. Both produce a silently
    // wrong route rather than a loud failure, so they fail closed in code.
    if (runtime.callerAgentSlug && runtime.callerAgentSlug === input.agentSlug) {
      return {
        ok: false,
        status: 'failed',
        agentSlug: input.agentSlug,
        toolUseCount: 0,
        toolNames: [],
        durationMs: 0,
        error: {
          code: 'self-delegation',
          message: `Cannot delegate to yourself (${input.agentSlug}). Do the work directly, or pick a different specialist.`,
        },
      };
    }
    if (this.deps.isAgentActive && !this.deps.isAgentActive(runtime.workspaceId, input.agentSlug)) {
      return {
        ok: false,
        status: 'failed',
        agentSlug: input.agentSlug,
        toolUseCount: 0,
        toolNames: [],
        durationMs: 0,
        error: {
          code: 'agent-not-active',
          message: `"${input.agentSlug}" is not active in this workspace. Activate it from the Workers page, or choose an active specialist with list_agents.`,
        },
      };
    }

    const workspaceRootPath = this.deps.getWorkspaceRootPath(runtime.workspaceId);
    const persist = () => {
      writeAgentMessageReceipt(workspaceRootPath, receipt);
      this.deps.onReceiptChanged?.(structuredClone(receipt));
    };
    const started = Date.now();
    const delegationKey = `${workspaceRootPath}:${runtime.parentRunId ?? runtime.parentSessionId ?? 'session'}:${runtime.parentStepId ?? ''}`;
    const reserved = await withDelegationMutex(delegationKey, () => {
      if (runtime.maxAgentMessages !== undefined) {
        const used = listAgentMessageReceipts(workspaceRootPath).filter((candidate) => (
          candidate.parentRunId === runtime.parentRunId
          && candidate.parentStepId === runtime.parentStepId
        )).length;
        if (used >= runtime.maxAgentMessages) return false;
      }
      persist();
      return true;
    });
    if (!reserved) {
      return {
        ok: false,
        status: 'failed',
        agentSlug: input.agentSlug,
        toolUseCount: 0,
        toolNames: [],
        durationMs: Math.max(0, Date.now() - started),
        error: {
          code: 'delegation-limit',
          message: `Workflow step delegation limit reached (${runtime.maxAgentMessages}).`,
        },
      };
    }

    try {
      const agentOptions = await this.deps.resolveAgentSessionOptions(
        runtime.workspaceId,
        input.agentSlug,
        input.taskModeId ? { taskModeId: input.taskModeId, taskModeSelectionSource: 'handoff' } : undefined,
      );
      if (runtime.voiceTask) {
        if (!this.deps.executeVoiceTurn || !this.deps.assertVoiceBackendSupported) throw new Error('Voice execution is unsupported.');
        this.deps.assertVoiceBackendSupported(runtime.workspaceId, agentOptions);
      }
      if (input.taskModeId && agentOptions.launchReceipt?.taskMode?.id !== input.taskModeId) {
        throw new Error(`Task mode "${input.taskModeId}" was not resolved for the target agent.`);
      }
      // A delegate must stay within both the caller and the specialist's defaults.
      const targetPermission = agentOptions.permissionMode ?? runtime.parentPermissionMode;
      if (rawInput.permissionMode && isPermissionEscalation(rawInput.permissionMode, targetPermission)) {
        throw new Error(`message_agent cannot raise permissionMode above target agent default (${targetPermission}).`);
      }
      const effectivePermission = isPermissionEscalation(input.permissionMode, targetPermission)
        ? targetPermission : input.permissionMode;
      for (const [kind, requested, allowed] of [
        ['source', input.sourceSlugs, agentOptions.enabledSourceSlugs],
        ['skill', input.skillSlugs, agentOptions.agentSkillSlugs],
      ] as const) {
        const unavailable = requested.filter(slug => !(allowed ?? []).includes(slug));
        if (unavailable.length) throw new Error(`Requested ${kind} slug(s) are not available to the target agent: ${unavailable.join(', ')}`);
      }
      if (input.sourceSlugs.length > 0 && this.deps.resolveUsableSourceSlugs) {
        const readiness = this.deps.resolveUsableSourceSlugs(runtime.workspaceId, input.sourceSlugs);
        if (readiness.unavailable.length > 0) {
          throw new Error(`Unavailable source(s): ${readiness.unavailable.join(', ')}`);
        }
      }

      const enabledSourceSlugs = input.sourceSlugs.length > 0
        ? input.sourceSlugs
        : agentOptions.enabledSourceSlugs;
      const agentSkillSlugs = input.skillSlugs.length > 0
        ? input.skillSlugs
        : agentOptions.agentSkillSlugs;
      const baseLaunchReceipt = agentOptions.launchReceipt;
      const baseInjected = baseLaunchReceipt?.injected;

      const child = await this.deps.createSession(runtime.workspaceId, {
        ...agentOptions,
        name: `Delegated: ${input.agentSlug}`,
        hidden: true,
        labels: [`agent-message-depth:${depth + 1}`],
        permissionMode: effectivePermission,
        enabledSourceSlugs,
        agentSkillSlugs,
        spawnedFromAgent: {
          agentSlug: input.agentSlug,
          agentName: baseLaunchReceipt?.agent?.name ?? input.agentSlug,
          timestamp: Date.now(),
        },
        launchReceipt: {
          ...baseLaunchReceipt,
          ...(runtime.voiceTask ? { voiceTask: { ...runtime.voiceTask, receiptId: receipt.id } } : {}),
          createdAt: Date.now(),
          origin: 'agent',
          automatedAncestry: runtime.automatedAncestry === true,
          delegation: {
            parentSessionId: runtime.parentSessionId,
            mechanism: 'message-agent',
            depth: depth + 1,
          },
          summary: `Delegated by ${runtime.callerAgentSlug ?? 'session'} via message_agent.`,
          agent: baseLaunchReceipt?.agent ?? {
            slug: input.agentSlug,
            name: input.agentSlug,
          },
          workflow: runtime.parentRunId && runtime.workflowSlug
            ? {
                runId: runtime.parentRunId,
                slug: runtime.workflowSlug,
                stepId: runtime.parentStepId,
                maxAgentMessages: runtime.maxAgentMessages,
              }
            : baseLaunchReceipt?.workflow,
          config: {
            ...(baseLaunchReceipt?.config ?? {}),
            permissionMode: effectivePermission,
            model: agentOptions.model,
            llmConnection: agentOptions.llmConnection,
            thinkingLevel: agentOptions.thinkingLevel,
            workingDirectory: typeof agentOptions.workingDirectory === 'string' ? agentOptions.workingDirectory : undefined,
          },
          injected: {
            ...(baseInjected ?? {}),
            systemPromptChars: baseInjected?.systemPromptChars ?? agentOptions.customSystemPrompt?.length,
            skills: agentSkillSlugs ?? baseInjected?.skills ?? [],
            sources: enabledSourceSlugs ?? baseInjected?.sources ?? [],
            contextDocs: baseInjected?.contextDocs ?? [],
          },
        },
      });

      receipt.childSessionId = child.id;
      receipt.policy.permissionMode = effectivePermission;
      receipt.constraints.sourceSlugs = enabledSourceSlugs ?? [];
      receipt.constraints.skillSlugs = agentSkillSlugs ?? [];
      receipt.updatedAt = now();
      persist();

      const prompt = buildDelegationPrompt(input, runtime);
      const startSend = () => (runtime.voiceTask ? this.deps.executeVoiceTurn! : this.deps.sendMessage)(child.id, prompt, {
        skillSlugs: agentSkillSlugs,
        displayIntent: 'agent-delegation-task',
      });
      const finish = (sendPromise: Promise<void | AgentMessageTerminalOutcome>) => this.finishDelegatedTurn({
        receipt,
        input,
        runtime,
        sendPromise,
        started,
        persist,
        now,
      });

      if (input.background) {
        await this.notifyBackgroundParentStarted(receipt, runtime);
        void finish(startSend()).catch(() => { /* durable record remains uncertain; bridge quarantines */ });
        return this.resultFromReceipt(receipt, started);
      }

      return await finish(startSend());
    } catch (error) {
      receipt.status = 'failed';
      receipt.error = {
        code: 'message-agent-failed',
        message: error instanceof Error ? error.message : String(error),
      };
      receipt.updatedAt = now();
      receipt.completedAt = receipt.updatedAt;
      persist();
      return this.resultFromReceipt(receipt, started);
    }
  }

  private async finishDelegatedTurn(input: {
    receipt: AgentMessageReceipt;
    input: ReturnType<typeof normalizeMessageAgentInput>;
    runtime: AgentMessageRuntimeContext;
    sendPromise: Promise<void | AgentMessageTerminalOutcome>;
    started: number;
    persist: () => void;
    now: () => string;
  }): Promise<MessageAgentResult> {
    const { receipt, runtime, sendPromise, started, persist, now } = input;
    const delegatedInput = input.input;

    try {
      const sent = await timeout(sendPromise, delegatedInput.timeoutSeconds * 1000);

      if (sent.timedOut) {
        if (receipt.childSessionId) {
          await this.deps.abortSession(receipt.childSessionId);
        }
        void drainAfterAbort(sendPromise);
        receipt.status = 'timed-out';
        receipt.error = { code: 'timeout', message: `Delegated agent timed out after ${delegatedInput.timeoutSeconds}s.` };
        receipt.updatedAt = now();
        receipt.completedAt = receipt.updatedAt;
        persist();
        await this.notifyBackgroundParent(receipt, runtime);
        return this.resultFromReceipt(receipt, started);
      }

      if (runtime.voiceTask) {
        const outcome = sent.value;
        receipt.executionOutcome = outcome || { generation: 0, reason: 'unknown' };
        if (!outcome || outcome.reason !== 'complete') {
          receipt.status = outcome?.reason === 'interrupted' ? 'cancelled' : outcome?.reason === 'timeout' ? 'timed-out' : 'failed';
          receipt.error = { code: outcome?.reason === 'unknown' || !outcome ? 'unknown-outcome' : 'execution-stopped', message: 'The specialist did not confirm a completed execution.' };
          receipt.updatedAt = now();
          receipt.completedAt = receipt.updatedAt;
          persist();
          await this.notifyBackgroundParent(receipt, runtime);
          return this.resultFromReceipt(receipt, started);
        }
      }
      const text = receipt.childSessionId ? this.deps.getLastAssistantText(receipt.childSessionId) : '';
      let output: unknown = text;
      if (delegatedInput.outputSchema) {
        const parsed = parseStructuredStepOutput(text, delegatedInput.outputSchema);
        if (!parsed.ok) {
          receipt.status = 'failed';
          receipt.error = { code: parsed.code, message: parsed.message };
          receipt.updatedAt = now();
          receipt.completedAt = receipt.updatedAt;
          persist();
          await this.notifyBackgroundParent(receipt, runtime);
          return this.resultFromReceipt(receipt, started);
        }
        output = parsed.value;
      }

      const toolSummary = receipt.childSessionId
        ? this.deps.getSessionToolUseSummary(receipt.childSessionId)
        : { count: 0, names: [] };
      receipt.status = 'succeeded';
      receipt.result = {
        output,
        summary: summaryFromOutput(output),
        toolUseCount: toolSummary.count,
        toolNames: toolSummary.names,
      };
      receipt.updatedAt = now();
      receipt.completedAt = receipt.updatedAt;
      persist();
      await this.notifyBackgroundParent(receipt, runtime);
      return this.resultFromReceipt(receipt, started);
    } catch (error) {
      receipt.status = 'failed';
      receipt.error = {
        code: 'message-agent-failed',
        message: error instanceof Error ? error.message : String(error),
      };
      receipt.updatedAt = now();
      receipt.completedAt = receipt.updatedAt;
      persist();
      await this.notifyBackgroundParent(receipt, runtime);
      return this.resultFromReceipt(receipt, started);
    }
  }

  private async notifyBackgroundParent(
    receipt: AgentMessageReceipt,
    runtime: AgentMessageRuntimeContext,
  ): Promise<void> {
    if (!receipt.policy.background || !runtime.parentSessionId || !this.deps.deliverPassiveMessage) return;

    const lines = [
      `Background agent "${receipt.targetAgentSlug}" ${receipt.status === 'succeeded' ? 'finished' : 'stopped'}.`,
      `receiptId: ${receipt.id}`,
      receipt.childSessionId ? `childSessionId: ${receipt.childSessionId}` : undefined,
      receipt.result?.summary ? `summary: ${receipt.result.summary}` : undefined,
      receipt.error ? `error: ${receipt.error.code}: ${receipt.error.message}` : undefined,
    ].filter(Boolean);

    try {
      await this.deps.deliverPassiveMessage(runtime.parentSessionId, lines.join('\n'), {
        receiptId: receipt.id,
        childSessionId: receipt.childSessionId,
        targetAgentSlug: receipt.targetAgentSlug,
        status: receipt.status,
        summary: receipt.result?.summary ?? (receipt.error ? `${receipt.error.code}: ${receipt.error.message}` : undefined),
        wakeEligible: true,
      });
    } catch {
      // Notification is best-effort; the receipt is the durable source of truth.
    }
  }

  private async notifyBackgroundParentStarted(
    receipt: AgentMessageReceipt,
    runtime: AgentMessageRuntimeContext,
  ): Promise<void> {
    if (!receipt.policy.background || !runtime.parentSessionId || !this.deps.deliverPassiveMessage) return;

    const lines = [
      `Background agent "${receipt.targetAgentSlug}" started.`,
      `receiptId: ${receipt.id}`,
      receipt.childSessionId ? `childSessionId: ${receipt.childSessionId}` : undefined,
    ].filter(Boolean);

    try {
      await this.deps.deliverPassiveMessage(runtime.parentSessionId, lines.join('\n'), {
        receiptId: receipt.id,
        childSessionId: receipt.childSessionId,
        targetAgentSlug: receipt.targetAgentSlug,
        status: 'running',
        wakeEligible: false,
      });
    } catch {
      // Notification is best-effort; the receipt is the durable source of truth.
    }
  }

  private resultFromReceipt(receipt: AgentMessageReceipt, started: number): MessageAgentResult {
    return {
      ok: receipt.status === 'succeeded' || receipt.status === 'running',
      status: receipt.status,
      receiptId: receipt.id,
      childSessionId: receipt.childSessionId,
      agentSlug: receipt.targetAgentSlug,
      output: receipt.result?.output,
      summary: receipt.result?.summary,
      toolUseCount: receipt.result?.toolUseCount ?? 0,
      toolNames: receipt.result?.toolNames ?? [],
      durationMs: Math.max(0, Date.now() - started),
      error: receipt.error,
    };
  }
}
