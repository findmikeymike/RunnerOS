import { VoiceTaskBridge } from '@craft-agent/server-core/voice-tasks'
import { ArtistManagerVoiceWorkService } from './artist-manager-voice-work'
import { recoverCampaignCleanupTransactions } from './campaign-cleanup-recovery'
import { createSafeRelaunch } from './safe-relaunch'
import { waitForSafeShutdown } from './shutdown-wait'
import { startElectronDurableWorkflowHost } from './durable-workflow-startup'
import { hasSavedDurableWorkflowStorage } from './durable-workflow-storage'
import { createDurableReadBindingResolver } from '@craft-agent/server-core/workflows/durable-read-binding'
import { electronDurableWorkflowLifetime } from './durable-workflow-lifetime'
import { artistStartupWindow } from './artist-startup-window'
import { app, BrowserWindow, dialog, ipcMain, nativeImage, nativeTheme, shell } from 'electron'
import { RUNTIME_IDENTITY } from '@craft-agent/shared/config/runtime-identity'
import { createBuiltInConnection, planOmniRouteTierRepair } from '@craft-agent/server-core/domain'
import { createHash, randomUUID } from 'crypto'
import { hostname, homedir } from 'os'
import * as Sentry from '@sentry/electron/main'

// Artist OS must establish its process and browser boundary before any
// Electron session, Sentry transport, window, or subprocess is initialized.
// Runner intentionally keeps Electron's existing userData behavior.
if (RUNTIME_IDENTITY.variant === 'artist-os') {
  process.env['CRAFT_CONFIG_DIR'] = RUNTIME_IDENTITY.dataRoot
  process.env['CRAFT_DEEPLINK_SCHEME'] = RUNTIME_IDENTITY.deeplinkScheme
  process.env['CRAFT_APP_NAME'] = RUNTIME_IDENTITY.productName
  app.setPath('userData', RUNTIME_IDENTITY.browserDataRoot)
}

// Initialize Sentry error tracking as early as possible after app import.
// Only enabled in production (packaged) builds to avoid noise during development.
// DSN is baked in at build time via esbuild --define (same pattern as OAuth secrets).
//
// NOTE: Source map upload is intentionally disabled. Stack traces in Sentry will show
// bundled/minified code. To enable source map upload in the future:
//   1. Add SENTRY_AUTH_TOKEN, SENTRY_ORG, SENTRY_PROJECT to CI secrets
//   2. Re-enable the @sentry/vite-plugin in vite.config.ts (handles renderer maps)
//   3. Add @sentry/esbuild-plugin to scripts/electron-build-main.ts (handles main process maps)
Sentry.init({
  dsn: process.env.SENTRY_ELECTRON_INGEST_URL,
  environment: app.isPackaged ? 'production' : 'development',
  release: app.getVersion(),
  // Enabled whenever the ingest URL is available — works in both production (baked via CI)
  // and development (injected via .env / 1Password). Filter by environment in Sentry dashboard.
  enabled: !!process.env.SENTRY_ELECTRON_INGEST_URL,

  // Scrub sensitive data before sending to Sentry.
  // Removes authorization headers, API keys/tokens, and credential-like values.
  beforeSend(event) {
    // Scrub request headers (authorization, cookies)
    if (event.request?.headers) {
      const sensitiveHeaders = ['authorization', 'cookie', 'x-api-key']
      for (const header of sensitiveHeaders) {
        if (event.request.headers[header]) {
          event.request.headers[header] = '[REDACTED]'
        }
      }
    }

    // Scrub breadcrumb data that may contain sensitive values
    if (event.breadcrumbs) {
      for (const breadcrumb of event.breadcrumbs) {
        if (breadcrumb.data) {
          for (const key of Object.keys(breadcrumb.data)) {
            const lowerKey = key.toLowerCase()
            if (lowerKey.includes('token') || lowerKey.includes('key') ||
                lowerKey.includes('secret') || lowerKey.includes('password') ||
                lowerKey.includes('credential') || lowerKey.includes('auth')) {
              breadcrumb.data[key] = '[REDACTED]'
            }
          }
        }
      }
    }

    return event
  },
})

// Initialize i18n for main process (menus, dialogs, etc.)
import { setupI18n, i18n } from '@craft-agent/shared/i18n'
setupI18n()

// Set anonymous machine ID for Sentry user tracking (no PII — just a hash).
// Uses hostname + homedir to produce a stable per-machine identifier.
const machineId = createHash('sha256').update(hostname() + homedir()).digest('hex').slice(0, 16)
Sentry.setUser({ id: machineId })

import { join, delimiter, dirname } from 'path'
import { existsSync, readFileSync } from 'fs'
import { RPC_CHANNELS } from '@craft-agent/shared/protocol'
import { SessionManager, setSessionPlatform, setSessionRuntimeHooks } from '@craft-agent/server-core/sessions'
import { assertProductLicensedChannel, getDesktopLicensing, initializeDesktopLicensing } from './licensing/runtime'
import { registerAllRpcHandlers } from './handlers/index'
import { registerCoreRpcHandlers, cleanupSessionFileWatchForClient } from '@craft-agent/server-core/handlers/rpc'
import type { PlatformServices } from '../runtime/platform'
import { createElectronPlatform } from './platform'
import type { HandlerDeps } from './handlers/handler-deps'
import { bootstrapServer, releaseServerLock } from '@craft-agent/server-core/bootstrap'
import { createMessagingBootstrap, type MessagingBootstrapHandle } from '@craft-agent/messaging-gateway'
import { getCredentialManager } from '@craft-agent/shared/credentials'
import { initModelRefreshService, getModelRefreshService, setFetcherPlatform } from '@craft-agent/server-core/model-fetchers'
import { setSearchPlatform, setImageProcessor } from '@craft-agent/server-core/services'
import { createApplicationMenu } from './menu'
import { WindowManager } from './window-manager'
import { loadWindowState, saveWindowState } from './window-state'
import { getWorkspaces, getWorkspaceByNameOrId, loadStoredConfig, addWorkspace, saveConfig, getLlmConnections, addLlmConnection, updateLlmConnection } from '@craft-agent/shared/config'
import { getDefaultWorkspacesDir } from '@craft-agent/shared/workspaces'
import { initializeDocs } from '@craft-agent/shared/docs'
import { initializeReleaseNotes } from '@craft-agent/shared/release-notes'
import { ensureDefaultPermissions } from '@craft-agent/shared/agent/permissions-config'
import { ensureToolIcons, ensurePresetThemes } from '@craft-agent/shared/config'
import { setBundledAssetsRoot } from '@craft-agent/shared/utils'
import { initializeBackendHostRuntime } from '@craft-agent/shared/agent/backend'
import { setPowerShellValidatorRoot } from '@craft-agent/shared/agent'
import { handleDeepLink } from './deep-link'
import { BrowserPaneManager } from './browser-pane-manager'
import { OAuthFlowStore } from '@craft-agent/shared/auth'
import { registerThumbnailScheme, registerThumbnailHandler } from './thumbnail-protocol'
import { registerOutputAssetHandler } from './output-asset-protocol'
import { registerProsodyIpcHandlers } from './prosody-engine'
import { registerChatDictationIpcHandlers } from './chat-dictation'
import { createArtistManagerMoonshine, type ArtistManagerMoonshine } from './artist-manager-moonshine'
import {
  EmbeddedOmniRoute,
  EMBEDDED_OMNIROUTE_BASE_URL,
  resolveEmbeddedOmniRoutePaths,
} from './embedded-omniroute'
import log, { isDebugMode, mainLog, getLogFilePath, getMessagingGatewayLogFilePath, messagingGatewayLog } from './logger'
import { setPerfEnabled, enableDebug } from '@craft-agent/shared/utils'
import { registerPiModelResolver } from '@craft-agent/shared/config'
import { getPiModelsForAuthProvider, getAllPiModels } from '@craft-agent/shared/config'
import { initNotificationService, initBadgeIcon, initInstanceBadge, updateBadgeCount } from './notifications'
import {
  checkForUpdatesOnLaunch,
  setAutoUpdateEventSink,
  setBeforeUpdateInstallHook,
  setBeforeUpdateQuitHook,
  setInstallQuitFailedHook,
} from './auto-update'
import type { EventSink } from '@craft-agent/server-core/transport'
import { validateGitBashPath, checkVCRedistInstalled } from '@craft-agent/server-core/services'
import {
  resolveScheduledSocialMediaPath,
  prepareScheduledSocialWork,
} from './campaign-social-job-preparer'
import { executeScheduledSocialBrowser } from './scheduled-social-browser-executor'
import { executeScheduledSocialAuto } from './scheduled-social-auto-executor'
import { createScheduledSocialProviderRoutes } from './scheduled-social-provider-executors'
import { runSocialJson } from './social-cli'
import {
  startArtistManagerVoiceProxy,
  type ArtistManagerVoiceProxy,
} from './artist-manager-voice-proxy'
import { ArtistManagerVoiceFocusService, validateVoiceSettingsRoute } from './artist-manager-voice-focus'
import { getArtistManagerVoiceSettings, updateArtistManagerVoiceSettings } from '@craft-agent/shared/config/artist-manager-voice-storage'

// Initialize electron-log for renderer process support
log.initialize()

// Enable debug/perf in dev mode (running from source)
if (isDebugMode) {
  process.env.CRAFT_DEBUG = '1'
  enableDebug()
  setPerfEnabled(true)
}

// Bundle CLI tools: resolve platform-specific uv binary and wrapper scripts.
// These are available to all agent Bash sessions via CRAFT_UV, CRAFT_SCRIPTS env vars
// and PATH prepend. uv auto-downloads Python 3.12 on first use (~5s, then cached).
{
  // In packaged app: resources are at process.resourcesPath/app/resources/
  // In dev: resources are at __dirname/../resources/ (sibling of dist/)
  const resourcesBase = app.isPackaged
    ? join(process.resourcesPath, 'app')
    : join(__dirname, '..')
  const platformKey = `${process.platform}-${process.arch}`
  const uvPlatformDir = join(resourcesBase, 'resources', 'bin', platformKey)
  const uvBinary = join(uvPlatformDir, process.platform === 'win32' ? 'uv.exe' : 'uv')
  const binDir = join(resourcesBase, 'resources', 'bin')
  const scriptsDir = join(resourcesBase, 'resources', 'scripts')

  const bundledUvExists = existsSync(uvBinary)
  const fallbackUv = bundledUvExists ? null : 'uv'

  // Runtime resolver hints for shared session tools
  process.env.CRAFT_IS_PACKAGED = app.isPackaged ? '1' : '0'
  process.env.CRAFT_RESOURCES_BASE = resourcesBase
  process.env.CRAFT_APP_ROOT = app.isPackaged ? app.getAppPath() : process.cwd()

  process.env.CRAFT_UV = bundledUvExists ? uvBinary : (fallbackUv ?? uvBinary)

  // Bun runtime (packaged builds should prefer bundled runtime over PATH)
  const bunBinary = join(resourcesBase, 'vendor', 'bun', process.platform === 'win32' ? 'bun.exe' : 'bun')
  if (existsSync(bunBinary)) {
    process.env.CRAFT_BUN = bunBinary
  }

  process.env.CRAFT_SCRIPTS = scriptsDir
  process.env.CRAFT_COMMANDS_ENTRY = app.isPackaged
    ? join(app.getAppPath(), 'packages', 'craft-agents-commands', 'src', 'main.ts')
    : join(process.cwd(), 'packages', 'craft-agents-commands', 'src', 'main.ts')
  process.env.CRAFT_CLI_ENTRY = app.isPackaged
    ? join(app.getAppPath(), 'packages', 'craft-cli', 'src', 'cli.ts')
    : join(process.cwd(), 'packages', 'craft-cli', 'src', 'cli.ts')
  process.env.CRAFT_COMMANDS_DOC_PATH = app.isPackaged
    ? join(resourcesBase, 'resources', 'docs', 'craft-cli.md')
    : join(process.cwd(), 'apps', 'electron', 'resources', 'docs', 'craft-cli.md')
  process.env.CRAFT_CLI_DOC_PATH = process.env.CRAFT_COMMANDS_DOC_PATH
  process.env.CRAFT_AGENT_VERSION = app.getVersion()
  // Prepend both generic wrappers dir and platform uv dir:
  // - binDir exposes wrapper commands (pdf-tool, docx-tool, ...)
  // - uvPlatformDir exposes raw `uv` for direct shell usage / debugging
  process.env.PATH = `${binDir}${delimiter}${uvPlatformDir}${delimiter}${process.env.PATH}`

  if (!bundledUvExists) {
    mainLog.warn('Bundled uv binary missing, CLI document tools may fail unless uv is available on PATH.', {
      expectedUvPath: uvBinary,
      usingCraftUv: process.env.CRAFT_UV,
    })
  }

  if (isDebugMode) {
    mainLog.info('CLI tools configured:', { uvBinary: process.env.CRAFT_UV, binDir, scriptsDir, bundledUvExists })
  }
}

// Register Pi model resolver so llm-connections.ts can resolve Pi models
// without importing @earendil-works/pi-ai (which breaks the Vite renderer build)
registerPiModelResolver((piAuthProvider) =>
  piAuthProvider ? getPiModelsForAuthProvider(piAuthProvider) : getAllPiModels()
)

// Custom URL scheme for deeplinks (e.g., craftagents://auth-complete)
// Supports multi-instance dev: CRAFT_DEEPLINK_SCHEME env var (craftagents1, craftagents2, etc.)
const DEEPLINK_SCHEME = RUNTIME_IDENTITY.variant === 'artist-os'
  ? RUNTIME_IDENTITY.deeplinkScheme
  : (process.env.CRAFT_DEEPLINK_SCHEME || RUNTIME_IDENTITY.deeplinkScheme)

let windowManager: WindowManager | null = null
let sessionManager: SessionManager | null = null
let browserPaneManager: BrowserPaneManager | null = null
let oauthFlowStore: OAuthFlowStore | null = null
let moduleSink: EventSink | null = null
let moduleClientResolver: ((webContentsId: number) => string | undefined) | null = null

// Messaging gateway: the bootstrap handle is created once sessionManager is
// available (inside createHandlerDeps) and populated with the WS publisher
// after bootstrapServer resolves. Both hosts (Electron + standalone) wire
// through createMessagingBootstrap — do not construct MessagingGatewayRegistry
// directly.
let messagingHandle: MessagingBootstrapHandle | null = null

// Inbound webhook trigger HTTP server handle. Held at module scope so the
// before-quit handler can stop it cleanly.
let triggerServerHandle: { url: string; stop: () => Promise<void> } | null = null
let artistManagerVoiceProxy: ArtistManagerVoiceProxy | null = null
let nativeVoiceTasks: VoiceTaskBridge | undefined
const nativeVoiceWorkEnabled = () => process.env.CRAFT_ARTIST_VOICE_WORK_BRIDGE === '1'
const artistManagerVoiceWork: ArtistManagerVoiceWorkService = new ArtistManagerVoiceWorkService({
  enabled: nativeVoiceWorkEnabled,
  delivered: (ownerId, sessionId, deliveryId, text) => artistManagerVoiceFocus.recordWorkDelivery(ownerId, sessionId, deliveryId, text),
  bridge: () => {
    if (!sessionManager) throw new Error('Session host is not ready')
    return nativeVoiceTasks ??= new VoiceTaskBridge(sessionManager.getVoiceTaskBridgeHost(), {
      enabled: nativeVoiceWorkEnabled,
      validateAuthority: (authority, binding) => {
        const ownerId = Number(authority.ownerId)
        if (!Number.isSafeInteger(ownerId) || windowManager?.getWorkspaceForWindow(ownerId) !== authority.workspaceId
          || artistManagerVoiceFocus.ownedWorkspace(ownerId, binding.voiceSessionId) !== authority.workspaceId) {
          throw new Error('Voice workspace is no longer active')
        }
      },
    })
  },
  workspace: (ownerId, sessionId): string => {
    const workspaceId = windowManager?.getWorkspaceForWindow(ownerId)
    if (!workspaceId || (sessionId && artistManagerVoiceFocus.ownedWorkspace(ownerId, sessionId) !== workspaceId)) throw new Error('Voice workspace is no longer active')
    return workspaceId
  },
})
const artistManagerVoiceFocus: ArtistManagerVoiceFocusService = new ArtistManagerVoiceFocusService(undefined, event => mainLog.info('[voice-handoff]', JSON.stringify(event)), artistManagerVoiceWork)
let artistManagerMoonshine: ArtistManagerMoonshine | null = null
let embeddedOmniRoute: EmbeddedOmniRoute | null = null

/**
 * How long startup waits for the embedded gateway before opening the app
 * anyway. It normally answers in a second or two; this is headroom, not a
 * budget the healthy path is expected to use.
 */
const OMNIROUTE_STARTUP_WAIT_MS = 8_000

// Store pending deep link if app not ready yet (cold start)
let pendingDeepLink: string | null = null

// Set app name early (before app.whenReady) to ensure correct macOS menu bar title
// Supports multi-instance dev: CRAFT_APP_NAME env var (e.g., "Runner [1]")
app.setName(
  RUNTIME_IDENTITY.variant === 'artist-os'
    ? RUNTIME_IDENTITY.productName
    : (process.env.CRAFT_APP_NAME || RUNTIME_IDENTITY.productName),
)

// Register as default protocol client for craftagents:// URLs
// This must be done before app.whenReady() on some platforms
if (process.defaultApp) {
  // Development mode: need to pass the app path
  if (process.argv.length >= 2) {
    app.setAsDefaultProtocolClient(DEEPLINK_SCHEME, process.execPath, [process.argv[1]])
  }
} else {
  // Production mode
  app.setAsDefaultProtocolClient(DEEPLINK_SCHEME)
}

// Apply network proxy settings early (Node-level only — Electron sessions require app.whenReady)
import { applyConfiguredProxySettings } from './network-proxy'

// Accept self-signed / untrusted certificates when connecting to a user-configured remote server.
// Only bypasses cert validation for the exact CRAFT_SERVER_URL origin — all other connections
// use standard certificate verification. Without this, wss:// to self-signed servers fails with
// ERR_CERT_AUTHORITY_INVALID because Chromium's WebSocket rejects untrusted certs.
//
// Electron's certificate-error always reports URLs with https:// scheme, so we normalize
// wss:// → https:// (and ws:// → http://) to ensure origins compare correctly.
function normalizeOriginForCert(urlStr: string): string {
  const u = new URL(urlStr)
  if (u.protocol === 'wss:') u.protocol = 'https:'
  else if (u.protocol === 'ws:') u.protocol = 'http:'
  return u.origin
}

if (process.env.CRAFT_SERVER_URL) {
  let serverOrigin: string | undefined
  try {
    serverOrigin = normalizeOriginForCert(process.env.CRAFT_SERVER_URL)
  } catch {
    // Invalid URL — will fail later during connection, no need to handle here
  }
  if (serverOrigin) {
    app.on('certificate-error', (event, _webContents, url, _error, _certificate, callback) => {
      try {
        if (normalizeOriginForCert(url) === serverOrigin) {
          event.preventDefault()
          callback(true)
          return
        }
      } catch {
        // URL parse failure — fall through to default rejection
      }
      callback(false)
    })
  }
}

// Register privileged custom protocols.
// Must happen before app.whenReady() — Electron requires early scheme registration.
registerThumbnailScheme()

// Handle deeplink on macOS (when app is already running)
app.on('open-url', (event, url) => {
  event.preventDefault()
  mainLog.info('Received deeplink:', url)

  if (windowManager) {
    handleDeepLink(url, windowManager, moduleSink ?? undefined, moduleClientResolver ?? undefined).catch(err => {
      mainLog.error('Failed to handle deep link:', err)
    })
  } else {
    // App not ready - store for later
    pendingDeepLink = url
  }
})

// Handle deeplink on Windows/Linux (single instance check)
const gotTheLock = app.requestSingleInstanceLock()
if (!gotTheLock) {
  app.quit()
} else {
  app.on('second-instance', (_event, commandLine, _workingDirectory) => {
    // Someone tried to run a second instance, we should focus our window.
    // On Windows/Linux, the deeplink is in commandLine
    const url = commandLine.find(arg => arg.startsWith(`${DEEPLINK_SCHEME}://`))
    if (url && windowManager) {
      mainLog.info('Received deeplink from second instance:', url)
      handleDeepLink(url, windowManager, moduleSink ?? undefined, moduleClientResolver ?? undefined).catch(err => {
        mainLog.error('Failed to handle deep link:', err)
      })
    } else if (windowManager) {
      // No deep link - just focus the first window
      const windows = windowManager.getAllWindows()
      if (windows.length > 0) {
        const win = windows[0].window
        if (win.isMinimized()) win.restore()
        win.focus()
      }
    }
  })
}

// Resolve interrupted, already-confirmed deletions before config loaders can
// recreate a staged campaign's original folder. Only the owning app recovers.
let campaignRecoveryWarnings: string[] = []
if (gotTheLock && RUNTIME_IDENTITY.variant === 'artist-os') {
  try {
    campaignRecoveryWarnings = recoverCampaignCleanupTransactions()
  } catch (error) {
    campaignRecoveryWarnings = [`Interrupted campaign cleanup could not be checked. Files were left in place: ${error instanceof Error ? error.message : String(error)}`]
  }
  for (const warning of campaignRecoveryWarnings) mainLog.warn('[campaign-cleanup]', warning)
}

// Proxy configuration reads workspace registration: recover before this read.
if (gotTheLock) void applyConfiguredProxySettings()

// Helper to create initial windows on startup
async function createInitialWindows(): Promise<void> {
  if (!windowManager) return

  // Load saved window state
  const savedState = loadWindowState()
  let workspaces = getWorkspaces()

  // If no workspaces exist, create default "My Workspace" on first run
  if (workspaces.length === 0) {
    // Ensure config file exists (addWorkspace requires it)
    if (!loadStoredConfig()) {
      saveConfig({ workspaces: [], activeWorkspaceId: null, activeSessionId: null })
    }
    const defaultPath = join(getDefaultWorkspacesDir(), 'my-workspace')
    addWorkspace({ rootPath: defaultPath, name: 'My Workspace' })
    workspaces = getWorkspaces() // Refresh after creation
    mainLog.info('Created default workspace on first run')
  }

  // Every Artist OS profile gets the local keyless route. Existing users keep
  // their selected/default provider; first-time users get OmniRoute by default
  // because addLlmConnection makes the first connection the default.
  const existingLlmConnections = getLlmConnections()
  if (RUNTIME_IDENTITY.variant === 'artist-os') {
    const existingOmniRoute = existingLlmConnections.find((connection) => connection.piAuthProvider === 'omniroute')
    if (!existingOmniRoute) {
      const connection = createBuiltInConnection('omniroute', EMBEDDED_OMNIROUTE_BASE_URL)
      if (addLlmConnection(connection)) {
        mainLog.info('[omniroute] Added keyless Auto connection for first use')
      }
    } else {
      // Only ever rewrite tier sets this app wrote itself as a default; a set
      // the artist picked is left exactly as it is. See planOmniRouteTierRepair
      // for why this repairs once rather than on every launch.
      const repair = planOmniRouteTierRepair(existingOmniRoute.models)
      if (repair) {
        updateLlmConnection(existingOmniRoute.slug, { ...repair, modelSelectionMode: 'userDefined3Tier' })
        mainLog.info('[omniroute] Pinned the default tier to the free route')
      }
    }
  }

  // A normal Artist OS launch starts with one HQ Overview window. Saved routes
  // still serve in-session switching; explicit pending deep links run afterward.
  const artistStartup = artistStartupWindow(RUNTIME_IDENTITY.variant, workspaces)
  if (artistStartup) {
    const win = windowManager.createWindow(artistStartup)
    const previous = savedState?.windows.find(saved => saved.workspaceId === artistStartup.workspaceId && !saved.focused)
      ?? savedState?.windows.find(saved => !saved.focused)
    if (previous) win.setBounds(previous.bounds)
    mainLog.info(`Opened Artist HQ Overview: ${artistStartup.workspaceId}`)
    return
  }

  const validWorkspaceIds = workspaces.map(ws => ws.id)

  if (savedState?.windows.length) {
    // Restore windows from saved state
    let restoredCount = 0

    for (const saved of savedState.windows) {
      // Skip invalid workspaces
      if (!validWorkspaceIds.includes(saved.workspaceId)) continue

      // Restore main window with focused mode if it was saved
      mainLog.info(`Restoring window: workspaceId=${saved.workspaceId}, focused=${saved.focused ?? false}, url=${saved.url ?? 'none'}`)
      const win = windowManager.createWindow({
        workspaceId: saved.workspaceId,
        focused: saved.focused,
        restoreUrl: saved.url,
      })
      win.setBounds(saved.bounds)

      restoredCount++
    }

    if (restoredCount > 0) {
      mainLog.info(`Restored ${restoredCount} window(s) from saved state`)
      return
    }
  }

  // Default: open window for first workspace
  windowManager.createWindow({ workspaceId: workspaces[0].id })
  mainLog.info(`Created window for first workspace: ${workspaces[0].name}`)
}

app.whenReady().then(async () => {
  // Export packaged state as env var so logger.ts (and headless Bun) don't need 'electron'
  process.env.CRAFT_IS_PACKAGED = app.isPackaged ? 'true' : 'false'


  if (RUNTIME_IDENTITY.variant === 'artist-os') {
    const paths = resolveEmbeddedOmniRoutePaths({
      appRootPath: app.getAppPath(),
      resourcesPath: process.resourcesPath,
      dataRoot: RUNTIME_IDENTITY.dataRoot,
      isPackaged: app.isPackaged,
    })
    if (paths) {
      embeddedOmniRoute = new EmbeddedOmniRoute(paths, {
        info: (message) => mainLog.info(message),
        warn: (message) => mainLog.warn(message),
        error: (message) => mainLog.error(message),
      })
      // Wait for the gateway, but not indefinitely. `start()` polls for up to
      // 45 seconds, and the window is not created until further down this
      // function — so on a machine where the gateway cannot start, awaiting it
      // outright means the artist stares at nothing for three quarters of a
      // minute and then gets a window anyway.
      //
      // Bounding the wait rather than the work: the gateway keeps starting in
      // the background and reports itself either way. The cost of moving on
      // early is at most one failed message if the artist types faster than the
      // gateway starts; the cost of waiting is a launch that looks broken.
      const started = embeddedOmniRoute.start()
      started
        .then((result) => { if (!result.ready) mainLog.error(`[omniroute] ${result.error}`) })
        .catch((error) => mainLog.error(`[omniroute] Gateway start failed: ${error instanceof Error ? error.message : String(error)}`))

      const readyInTime = await Promise.race([
        started.then((result) => result.ready).catch(() => false),
        new Promise<boolean>((resolve) => setTimeout(() => resolve(false), OMNIROUTE_STARTUP_WAIT_MS)),
      ])
      if (!readyInTime) {
        mainLog.warn(`[omniroute] Gateway not ready within ${OMNIROUTE_STARTUP_WAIT_MS}ms; opening the app and letting it finish in the background`)
      }
    } else {
      mainLog.error('[omniroute] Bundled runtime paths could not be resolved')
    }

    await initializeDesktopLicensing()
    artistManagerVoiceProxy = await startArtistManagerVoiceProxy()
  }

  // Register bundled assets root so all seeding functions can find their files
  // (docs, permissions, themes, tool-icons resolve via getBundledAssetsDir)
  setBundledAssetsRoot(__dirname)

  // Initialize backend runtime bootstrapping (Codex vendor root, Claude SDK runtime paths).
  initializeBackendHostRuntime({
    hostRuntime: {
      appRootPath: app.getAppPath(),
      resourcesPath: process.resourcesPath,
      isPackaged: app.isPackaged,
    },
  })

  // Register PowerShell validator root so it can find the bundled parser script
  // (Windows only: validates PowerShell commands in Explore mode using AST analysis)
  setPowerShellValidatorRoot(join(__dirname, 'resources'))

  // Initialize bundled docs
  initializeDocs()

  // Initialize bundled release notes
  initializeReleaseNotes()

  // Ensure default permissions file exists (copies bundled default.json on first run)
  ensureDefaultPermissions()

  // Seed tool icons to ~/.craft-agent/tool-icons/ (copies bundled SVGs on first run)
  ensureToolIcons()

  // Seed preset themes to ~/.craft-agent/themes/ (copies bundled theme JSONs on first run)
  ensurePresetThemes()

  // Register thumbnail:// protocol handler (scheme was registered earlier, before app.whenReady)
  registerThumbnailHandler()
  registerOutputAssetHandler()

  // Re-apply proxy settings now that Electron sessions are available
  // (first call before app.whenReady only configured Node-level proxy)
  await applyConfiguredProxySettings()

  // Note: electron-updater handles pending updates internally via autoInstallOnAppQuit

  // Application menu is created after windowManager initialization (see below)

  // Set dock icon on macOS (required for dev mode, bundled apps use Info.plist)
  if (process.platform === 'darwin' && app.dock) {
    // In packaged app, resources are at dist/resources/ (same level as __dirname)
    // In dev, resources are at ../resources/ (sibling of dist/)
    const dockIconName = RUNTIME_IDENTITY.variant === 'artist-os' ? 'artist-os-icon.png' : 'icon.png'
    const dockIconPath = [
      join(__dirname, 'resources', dockIconName),
      join(__dirname, '../resources', dockIconName),
    ].find(p => existsSync(p))

    if (dockIconPath) {
      app.dock.setIcon(dockIconPath)
      // Initialize badge icon for canvas-based badge overlay
      initBadgeIcon(dockIconPath)
    }

    // Multi-instance dev: show instance number badge on dock icon
    // CRAFT_INSTANCE_NUMBER is set by detect-instance.sh for numbered folders
    const instanceNum = process.env.CRAFT_INSTANCE_NUMBER
    if (instanceNum) {
      const num = parseInt(instanceNum, 10)
      if (!isNaN(num) && num > 0) {
        initInstanceBadge(num)
      }
    }
  }

  try {
    // Initialize window manager
    windowManager = new WindowManager()

    // Create the application menu (needs windowManager for New Window action)
    createApplicationMenu(windowManager)

    // When CRAFT_SERVER_URL is set, this Electron instance is a thin client —
    // it only creates windows whose preload connects to the remote server.
    // Skip server-side initialization (SessionManager, model refresh, platform injection).
    const isClientOnly = !!process.env.CRAFT_SERVER_URL
    const isHeadless = !!process.env.CRAFT_HEADLESS

    if (isClientOnly) {
      mainLog.info(`Client-only mode: CRAFT_SERVER_URL=${process.env.CRAFT_SERVER_URL} (server initialization skipped)`)
    }

    // Initialize notification service (always — triggered by server push events)
    initNotificationService(windowManager)

    // Initialize browser pane manager (always — even in headless, for deps wiring)
    browserPaneManager = new BrowserPaneManager()
    browserPaneManager.setWindowManager(windowManager)
    if (RUNTIME_IDENTITY.variant === 'artist-os') {
      browserPaneManager.setPaidExecutionAuthorizer(() => assertProductLicensedChannel('browser-pane:navigate'))
      getDesktopLicensing().subscribe((snapshot) => {
        if (!snapshot.authorized && snapshot.state !== 'ACTIVATING' && snapshot.state !== 'SERVICE_UNAVAILABLE') {
          browserPaneManager?.suspendPaidExecution()
        }
      })
    }
    browserPaneManager.registerToolbarIpc()

    // Build real PlatformServices from Electron APIs
    const platform: PlatformServices = createElectronPlatform({
      app,
      nativeImage,
      shell,
      nativeTheme,
      logger: log,
      isDebugMode,
      getLogFilePath,
      captureError: (err) => Sentry.captureException(err),
    })

    // Bootstrap IPC handlers — preload uses sendSync for window-local details
    ipcMain.on('__get-web-contents-id', (e) => {
      e.returnValue = e.sender.id
    })
    ipcMain.on('__get-workspace-id', (e) => {
      e.returnValue = windowManager?.getWorkspaceForWindow(e.sender.id) ?? ''
    })

    // Transport diagnostics bridge — preload reports remote WS connection state changes
    // so failures are visible in terminal/main.log (not only renderer console).
    ipcMain.on('__transport:status', (_event, payload: unknown) => {
      if (!payload || typeof payload !== 'object') return
      const p = payload as {
        level?: 'info' | 'warn' | 'error'
        message?: string
        status?: string
        attempt?: number
        nextRetryInMs?: number
        error?: unknown
        close?: unknown
        url?: string
      }

      const level = p.level ?? 'info'
      const message = p.message ?? '[transport] status update'
      const context = {
        status: p.status,
        attempt: p.attempt,
        nextRetryInMs: p.nextRetryInMs,
        error: p.error,
        close: p.close,
        url: p.url,
      }

      if (level === 'error') {
        mainLog.error(message, context)
      } else if (level === 'warn') {
        mainLog.warn(message, context)
      } else {
        mainLog.info(message, context)
      }
    })

    // Dialog bridge — preload capability handlers use ipcRenderer.invoke to
    // call main-process-only dialog APIs (dialog, BrowserWindow).
    ipcMain.handle('__dialog:showMessageBox', async (event, spec) => {
      const win = BrowserWindow.fromWebContents(event.sender)
        || BrowserWindow.getFocusedWindow()
        || BrowserWindow.getAllWindows()[0]
      const result = await dialog.showMessageBox(win, spec)
      return { response: result.response }
    })
    // Electron 43+ opens every dialog in ~/Downloads unless `defaultPath` is
    // set, and stops the OS from remembering the last-used folder. Picking a
    // workspace or a vault folder from Downloads every time is a regression
    // for this app, so remember the last folder ourselves — the pattern the
    // Electron breaking-changes notes recommend.
    let lastOpenDialogDir: string | undefined
    ipcMain.handle('__dialog:showOpenDialog', async (event, spec) => {
      const win = BrowserWindow.fromWebContents(event.sender)
        || BrowserWindow.getFocusedWindow()
        || BrowserWindow.getAllWindows()[0]
      const options = spec?.defaultPath || !lastOpenDialogDir
        ? spec
        : { ...spec, defaultPath: lastOpenDialogDir }
      const result = await dialog.showOpenDialog(win, options)
      if (!result.canceled && result.filePaths[0]) {
        lastOpenDialogDir = dirname(result.filePaths[0])
      }
      return { canceled: result.canceled, filePaths: result.filePaths }
    })
    ipcMain.handle('__visual:capture-element', async (event, rect: { x?: number; y?: number; width?: number; height?: number }) => {
      const x = Math.max(0, Math.floor(Number(rect?.x) || 0))
      const y = Math.max(0, Math.floor(Number(rect?.y) || 0))
      const width = Math.min(2400, Math.max(1, Math.floor(Number(rect?.width) || 0)))
      const height = Math.min(1800, Math.max(1, Math.floor(Number(rect?.height) || 0)))
      if (width < 8 || height < 8) throw new Error('Visual capture target is too small.')
      const image = await event.sender.capturePage({ x, y, width, height })
      if (image.isEmpty()) throw new Error('Visual capture returned an empty image.')
      return {
        dataUrl: image.toDataURL(),
        width: image.getSize().width,
        height: image.getSize().height,
      }
    })
    ipcMain.handle('__artist-manager-voice:proxy-info', () => {
      if (!artistManagerVoiceProxy) throw new Error('Artist Manager voice is unavailable in this app mode')
      return artistManagerVoiceProxy.info()
    })
    ipcMain.handle('__artist-manager-voice:provider-status', () => {
      if (!artistManagerVoiceProxy) throw new Error('Artist Manager voice is unavailable in this app mode')
      return artistManagerVoiceProxy.providerStatus()
    })
    ipcMain.handle('__artist-manager-voice:assembly-token', () => {
      if (!artistManagerVoiceProxy) throw new Error('Artist Manager voice is unavailable in this app mode')
      return artistManagerVoiceProxy.createAssemblyAiToken()
    })
    artistManagerMoonshine = createArtistManagerMoonshine({
      isPackaged: app.isPackaged,
      resourcesDirectory: app.isPackaged ? process.resourcesPath : join(__dirname, '..', '.voice-core-dev', 'resources'),
      userDataDirectory: app.getPath('userData'),
    })
    const observedVoiceSenders = new WeakSet<Electron.WebContents>()
    const focusOwner = (event: Electron.IpcMainInvokeEvent) => {
      const sender = event.sender
      if (!artistManagerVoiceProxy || sender.isDestroyed() || event.senderFrame !== sender.mainFrame
        || !windowManager?.getAllWindows().some(({ window }) => window.webContents === sender)) {
        throw new Error('Focused voice is restricted to the local app main window')
      }
      if (!observedFocusSenders.has(sender)) {
        observedFocusSenders.add(sender)
        const release = () => { artistManagerVoiceWork.detachOwner(sender.id); artistManagerVoiceFocus.stopOwner(sender.id) }
        sender.once('destroyed', release)
        sender.on('render-process-gone', release)
        sender.on('did-start-navigation', (_event, _url, isInPlace, isMainFrame) => {
          if (isMainFrame && !isInPlace) release()
        })
      }
      return sender
    }
    const observedFocusSenders = new WeakSet<Electron.WebContents>()
    ipcMain.handle('__artist-manager-voice-settings:get', event => {
      focusOwner(event)
      return getArtistManagerVoiceSettings()
    })
    ipcMain.handle('__artist-manager-voice-settings:update', async (event, value: unknown) => {
      focusOwner(event)
      // Refuse malformed persisted settings before route lookup can load config migrations.
      await getArtistManagerVoiceSettings()
      const settings = await validateVoiceSettingsRoute(value)
      focusOwner(event)
      return updateArtistManagerVoiceSettings(settings)
    })
    ipcMain.handle('__artist-manager-voice-focus:register', (event, request) => {
      const owner = focusOwner(event).id
      if (!request || request.workspaceId !== windowManager?.getWorkspaceForWindow(owner)) throw new Error('Voice workspace is no longer active')
      artistManagerVoiceWork.detachOwner(owner)
      return artistManagerVoiceFocus.register(owner, request)
    })
    ipcMain.handle('__artist-manager-voice-work:invoke', (event, request) => artistManagerVoiceWork.invoke(focusOwner(event).id, request))
    ipcMain.handle('__artist-manager-voice-work:subscribe', (event, request) => {
      const sender = focusOwner(event)
      return artistManagerVoiceWork.subscribe(sender.id, request, value => {
        if (!sender.isDestroyed()) sender.send('__artist-manager-voice-work:event', value)
      })
    })
    ipcMain.handle('__artist-manager-voice-focus:turn', (event, request) => {
      const sender = focusOwner(event)
      return artistManagerVoiceFocus.startTurn(sender.id, request, value => {
        if (!sender.isDestroyed()) sender.send('__artist-manager-voice-focus:event', value)
      })
    })
    ipcMain.handle('__artist-manager-voice-focus:cancel', (event, request) =>
      artistManagerVoiceFocus.cancel(focusOwner(event).id, request))
    ipcMain.handle('__artist-manager-voice-focus:stop', (event, sessionId) => {
      const owner = focusOwner(event).id
      if (sessionId !== undefined) artistManagerVoiceFocus.ownedWorkspace(owner, sessionId)
      artistManagerVoiceWork.detachOwner(owner)
      if (sessionId === undefined) artistManagerVoiceFocus.stopOwner(owner)
      else artistManagerVoiceFocus.stop(owner, sessionId)
    })
    ipcMain.handle('__artist-manager-moonshine:invoke', async (event, request: unknown) => {
      const sender = event.sender
      if (sender.isDestroyed() || event.senderFrame !== sender.mainFrame
        || !windowManager?.getAllWindows().some(({ window }) => window.webContents === sender)) {
        throw new Error('Moonshine is restricted to the app main window')
      }
      if (!observedVoiceSenders.has(sender)) {
        observedVoiceSenders.add(sender)
        const release = () => { void artistManagerMoonshine?.releaseOwner(sender.id).catch(error => mainLog.warn('[moonshine] owner cleanup failed', error)) }
        sender.once('destroyed', release)
        sender.on('render-process-gone', release)
        sender.on('did-start-navigation', (_event, _url, isInPlace, isMainFrame) => {
          if (isMainFrame && !isInPlace) release()
        })
      }
      if (!artistManagerMoonshine) throw new Error('Moonshine is unavailable')
      return artistManagerMoonshine.invoke(sender.id, request)
    })
    registerProsodyIpcHandlers()
    registerChatDictationIpcHandlers()

    if (!isClientOnly) {
      // Restore persisted Git Bash path on Windows (must happen before any SDK subprocess spawn)
      if (process.platform === 'win32') {
        const { getGitBashPath, clearGitBashPath } = await import('@craft-agent/shared/config')
        const gitBashPath = getGitBashPath()
        if (gitBashPath) {
          const validation = await validateGitBashPath(gitBashPath)
          if (validation.valid) {
            process.env.CLAUDE_CODE_GIT_BASH_PATH = validation.path
          } else {
            clearGitBashPath()
            delete process.env.CLAUDE_CODE_GIT_BASH_PATH
            mainLog.warn(`Cleared invalid persisted Git Bash path: ${gitBashPath}`)
          }
        }
      }

      // Check for VC++ Redistributable on Windows (required by onnxruntime / markitdown).
      // Without it, document conversion tools (PDF, PPTX, DOCX, XLSX) crash with DLL errors.
      // Sets env var so renderer can show an actionable toast with install button.
      if (process.platform === 'win32') {
        const vcCheck = checkVCRedistInstalled()
        if (!vcCheck.installed) {
          mainLog.warn('[vcredist]', vcCheck.message)
          process.env.CRAFT_VCREDIST_MISSING = '1'
          if (vcCheck.downloadUrl) {
            process.env.CRAFT_VCREDIST_URL = vcCheck.downloadUrl
          }
        } else if (isDebugMode) {
          mainLog.info('[vcredist]', vcCheck.message)
        }
      }

      // Pre-import power manager (async import needed for applyPlatformToSubsystems)
      const { onSessionStarted, onSessionStopped, setTeamRunnerActive } = await import('./power-manager')

      // Client ID tracking for Electron IPC bridge (webContentsId → clientId)
      const clientMap = new Map<number, string>()
      const resolveClientId = (wcId: number) => clientMap.get(wcId)

      // Read embedded server config (Server settings page)
      const { getServerConfig } = await import('@craft-agent/shared/config')
      const embeddedServerConfig = getServerConfig()
      const serverModeEnabled = embeddedServerConfig.enabled && !isClientOnly

      // Derive host/port/token from server config (or env overrides)
      const serverToken = serverModeEnabled && embeddedServerConfig.token
        ? embeddedServerConfig.token
        : randomUUID()
      const rpcHost = process.env.CRAFT_RPC_HOST
        ?? (serverModeEnabled ? '0.0.0.0' : '127.0.0.1')
      const rpcPort = process.env.CRAFT_RPC_PORT
        ? parseInt(process.env.CRAFT_RPC_PORT, 10)
        : (serverModeEnabled ? embeddedServerConfig.port : 0)

      // Load TLS certificates if configured
      let tls: import('@craft-agent/server-core/transport').WsRpcTlsOptions | undefined
      if (serverModeEnabled && embeddedServerConfig.tlsCertPath && embeddedServerConfig.tlsKeyPath) {
        try {
          tls = {
            cert: readFileSync(embeddedServerConfig.tlsCertPath),
            key: readFileSync(embeddedServerConfig.tlsKeyPath),
          }
          mainLog.info('[server-mode] TLS enabled')
        } catch (err) {
          mainLog.error('[server-mode] Failed to load TLS certificates:', err)
        }
      }

      if (serverModeEnabled) {
        mainLog.info(`[server-mode] Enabled — binding ${rpcHost}:${rpcPort}${tls ? ' (TLS)' : ''}`)
      }

      // Bootstrap the WS RPC server via shared bootstrap function.
      let durableHandlerDeps: HandlerDeps | undefined
      const durableHostEnabled = RUNTIME_IDENTITY.variant === 'artist-os' && process.env.CRAFT_DURABLE_READ_HOST === '1'
      const durableRecoveryRequired = RUNTIME_IDENTITY.variant === 'artist-os' && (durableHostEnabled || hasSavedDurableWorkflowStorage(RUNTIME_IDENTITY.dataRoot))
      const instance = await bootstrapServer<SessionManager, HandlerDeps>({
        serverToken,
        rpcHost,
        rpcPort,
        tls,
        bundledAssetsRoot: __dirname,
        serverId: 'local',
        serverVersion: app.getVersion(),
        authorizeRequest: (_context, channel) => assertProductLicensedChannel(channel),
        platformFactory: () => platform,
        applyPlatformToSubsystems: (p) => {
          setFetcherPlatform(p)
          setSessionPlatform(p)
          setSessionRuntimeHooks({
            updateBadgeCount,
            onSessionStarted,
            onSessionStopped,
            onTeamRunnerActiveChange: setTeamRunnerActive,
            validateSocialProfile: async ({ platform, profileId }) => {
              const { runSocialJson } = await import('./social-cli')
              const doctor = await runSocialJson(['doctor', '--json']) as {
                platforms?: Array<{ profiles?: Array<{ platform?: string; profile?: string; ready?: boolean; localSessionExists?: boolean; accountHandle?: string | null; accountUrl?: string | null }> }>
              }
              const profile = doctor.platforms?.flatMap((group) => group.profiles ?? [])
                .find((candidate) => candidate.platform === platform && candidate.profile === profileId)
              return profile?.ready || (profile?.localSessionExists && Boolean(profile.accountHandle || profile.accountUrl))
                ? { ready: true }
                : { ready: false, reason: 'Social profile login or setup is required.' }
            },
            captureException: (error, context) => {
              Sentry.captureException(error instanceof Error ? error : new Error(String(error)), {
                tags: {
                  ...(context?.errorSource ? { errorSource: context.errorSource } : {}),
                  ...(context?.sessionId ? { sessionId: context.sessionId } : {}),
                },
              })
            },
          })
          setSearchPlatform(p)
          setImageProcessor(p.imageProcessor)
        },
        createSessionManager: () => {
          const sm = new SessionManager()
          if (RUNTIME_IDENTITY.variant === 'artist-os') {
            sm.setPaidExecutionAuthorizer(() => getDesktopLicensing().isPaidExecutionAuthorized())
            getDesktopLicensing().subscribe((snapshot) => {
              if (!snapshot.authorized && snapshot.state !== 'ACTIVATING' && snapshot.state !== 'SERVICE_UNAVAILABLE') {
                void sm.suspendPaidExecution()
              }
            })
          }
          sm.setScheduledSocialExecution(
            (input) => prepareScheduledSocialWork(input, { runSocialJson, resolveWorkspace: getWorkspaceByNameOrId }),
            (input) => executeScheduledSocialAuto(input, {
              providerRoutes: createScheduledSocialProviderRoutes({
                resolveMediaPath: (rootPath, order) => resolveScheduledSocialMediaPath(rootPath, order, getWorkspaceByNameOrId),
              }),
              executeBrowser: (browserInput) => executeScheduledSocialBrowser(browserInput, {
                browserPaneManager: browserPaneManager!,
                resolveMediaPath: (rootPath, order) => resolveScheduledSocialMediaPath(rootPath, order, getWorkspaceByNameOrId),
              }),
              log: (message) => console.info(`[ScheduledSocial] ${message}`),
            }),
          )
          sm.setBrowserPaneManager(browserPaneManager!)
          return sm
        },
        createHandlerDeps: ({ sessionManager: sm, platform: p, oauthFlowStore: ofs }) => {
          // The messaging handle is built here because it needs sessionManager.
          // The WS publisher is attached after bootstrapServer resolves (via
          // handle.setPublisher) because wsServer isn't available yet.
          messagingHandle = createMessagingBootstrap({
            sessionManager: sm,
            credentialManager: getCredentialManager(),
            // Fires MessageReceive automations on every inbound chat message.
            // Errors are swallowed inside the gateway so a bad automation
            // never blocks chat routing.
            onIncomingMessage: async (workspaceId, event) => {
              const automationSystem = sm.getAutomationSystemForWorkspaceId(workspaceId)
              if (!automationSystem) return
              await automationSystem.fireMessageReceive({
                platform: event.platform,
                channelId: event.channelId,
                messageId: event.messageId,
                senderId: event.senderId,
                senderName: event.senderName,
                text: event.text,
                bound: event.bound,
                wasBound: event.wasBound,
                boundAfterRoute: event.boundAfterRoute,
                attachmentCount: event.attachmentCount,
                sentAt: event.sentAt,
              })
            },
            getMessagingDir: (wsId: string) =>
              join(RUNTIME_IDENTITY.workspacesRoot, wsId, 'messaging'),
            getLegacyMessagingDir: (wsId: string) => {
              const ws = getWorkspaces().find((w) => w.id === wsId)
              return ws ? join(ws.rootPath, 'messaging') : undefined
            },
            // Route messaging diagnostics through the dedicated messaging log
            // at ~/.craft-agent/logs/messaging-gateway.log.
            logger: messagingGatewayLog,
            // WhatsApp worker runs under Electron's embedded Node via
            // ELECTRON_RUN_AS_NODE (WhatsAppAdapter defaults nodeBin to
            // process.execPath). In dev we resolve worker.cjs from the
            // monorepo; in packaged builds it's shipped via extraResources
            // (see apps/electron/electron-builder.common.yml).
            whatsapp: {
              workerEntry: app.isPackaged
                ? join(process.resourcesPath, 'messaging-whatsapp-worker', 'worker.cjs')
                : join(process.cwd(), 'packages', 'messaging-whatsapp-worker', 'dist', 'worker.cjs'),
              pairingMode: 'qr',
            },
          })
          sm.setAutomationMessagingBinder(({ workspaceId, agentSlug, sessionId, platform, channelId, channelName }) => {
            messagingHandle?.registry.bindAutomationSession(workspaceId, agentSlug, sessionId, platform, channelId, channelName)
          })
          const deps: HandlerDeps = {
            sessionManager: sm,
            platform: p,
            windowManager: windowManager ?? undefined,
            browserPaneManager: browserPaneManager ?? undefined,
            oauthFlowStore: ofs,
            messagingRegistry: messagingHandle.registry,
            // Closure: trigger server starts after bootstrapServer resolves.
            // Reading the live module-scoped handle on each call gives the
            // renderer the current URL even if the server is restarted.
            getTriggerServerInfo: () => ({
              enabled: triggerServerHandle != null,
              url: triggerServerHandle?.url ?? null,
            }),
            getWorkflowRunner: () => sm.getWorkflowRunner(),
            getDeepResearchRunner: () => sm.getDeepResearchRunner(),
            validateSocialProfile: async ({ platform, profileId }) => {
              const { runSocialJson } = await import('./social-cli')
              const doctor = await runSocialJson(['doctor', '--json']) as {
                platforms?: Array<{ profiles?: Array<{ platform?: string; profile?: string; ready?: boolean; localSessionExists?: boolean; accountHandle?: string | null; accountUrl?: string | null }> }>
              }
              const profile = doctor.platforms?.flatMap((group) => group.profiles ?? [])
                .find((candidate) => candidate.platform === platform && candidate.profile === profileId)
              return profile?.ready || (profile?.localSessionExists && Boolean(profile.accountHandle || profile.accountUrl))
                ? { ready: true }
                : { ready: false, reason: 'Social profile login or setup is required.' }
            },
            getNotificationService: () => sm.getNotificationService(),
          }
          durableHandlerDeps = deps
          return deps
        },
        // Headless: register only core handlers (no GUI handlers for browser, settings, etc.)
        // GUI: register all handlers (core + GUI)
        registerAllRpcHandlers: isHeadless
          ? (server, deps, serverCtx) => registerCoreRpcHandlers(server, deps, serverCtx)
          : registerAllRpcHandlers,
        setSessionEventSink: (sm, sink) => sm.setEventSink(sink),
        initializeSessionManager: (sm) => {
          if (durableRecoveryRequired) sm.deferScheduledWorkForDurableHost()
          return sm.initialize()
        },
        initModelRefreshService: () => initModelRefreshService(async (slug: string) => {
          const { getCredentialManager } = await import('@craft-agent/shared/credentials')
          const manager = getCredentialManager()
          const [apiKey, oauth] = await Promise.all([
            manager.getLlmApiKey(slug).catch(() => null),
            manager.getLlmOAuth(slug).catch(() => null),
          ])
          return {
            apiKey: apiKey ?? undefined,
            oauthAccessToken: oauth?.accessToken,
            oauthRefreshToken: oauth?.refreshToken,
            oauthIdToken: oauth?.idToken,
          }
        }),
        onClientConnected: ({ clientId, webContentsId }) => {
          if (webContentsId != null) clientMap.set(webContentsId, clientId)
        },
        cleanupClientResources: (clientId) => {
          for (const [wcId, cId] of clientMap) {
            if (cId === clientId) { clientMap.delete(wcId); break }
          }
          cleanupSessionFileWatchForClient(clientId)
        },
      })

      // Host opt-in: supported manual and tracked scheduled reads use durable Start.
      if (durableHostEnabled) {
        try {
          const durableHost = await startElectronDurableWorkflowHost({
            enabled: true,
            server: instance.wsServer,
            getBinding: () => ({ host: rpcHost, serverModeEnabled: serverModeEnabled || getServerConfig().enabled }),
            runnerOptions: {
              hostRuntime: { appRootPath: app.getAppPath(), resourcesPath: process.resourcesPath, isPackaged: app.isPackaged },
              resolveBinding: createDurableReadBindingResolver(),
              onOutputPublished: (workspaceId, outputId) => instance.sessionManager.notifyDurableOutputPublished(workspaceId, outputId),
            },
          })
          if (durableHost && durableHandlerDeps) {
            durableHandlerDeps.getDurableWorkflowControls = () => durableHost.controls
            durableHandlerDeps.getDurableWorkflowRuns = () => durableHost.runs
            instance.sessionManager.setDurableWorkflowHost(durableHost)
          }
        } catch {
          // Do not expose keychain/credential details. Unknown recovery state blocks new workflow admission.
          mainLog.error('[durable-workflows] Host unavailable; durable controls remain disabled')
          void dialog.showMessageBox({
            type: 'warning', title: 'Workflow recovery unavailable',
            message: 'The optional workflow recovery host could not start.',
            detail: 'Scheduled work and new workflow starts are paused until recovery storage is available. Check secure-storage access and local-only server settings before trying again on the next launch.',
            buttons: ['OK'],
          }).catch(() => mainLog.warn('[durable-workflows] Startup notice could not be displayed'))
        } finally {
          instance.sessionManager.finishDurableWorkflowStartup()
        }
      } else if (durableRecoveryRequired) {
        mainLog.warn('[durable-workflows] Saved recovery storage exists; workflow admission remains paused while the host is disabled')
        void dialog.showMessageBox({
          type: 'warning', title: 'Workflow recovery required',
          message: 'Saved workflow recovery data needs the recovery host.',
          detail: 'Scheduled work and new workflow starts are paused to preserve saved runs. Restart this development build with CRAFT_DURABLE_READ_HOST=1 to reconnect them.',
          buttons: ['OK'],
        }).catch(() => mainLog.warn('[durable-workflows] Disabled-host notice could not be displayed'))
      }

      // Capture module-level references for before-quit cleanup and deep-link handlers
      sessionManager = instance.sessionManager
      if (campaignRecoveryWarnings.length) {
        const hq = getWorkspaces().find(workspace => workspace.artistWorkspaceScope === 'hq' && !workspace.remoteServer)
        if (hq) {
          try {
            sessionManager.getNotificationService().add({
              workspaceId: hq.id, source: 'system', title: 'Campaign cleanup recovery',
              message: campaignRecoveryWarnings.join('\n'), urgency: 'normal',
            })
          } catch (error) { mainLog.warn('[campaign-cleanup] Could not save recovery notice', error) }
        }
      }
      oauthFlowStore = instance.oauthFlowStore
      moduleSink = instance.wsServer.push.bind(instance.wsServer)
      moduleClientResolver = resolveClientId

      // -----------------------------------------------------------------------
      // Inbound webhook trigger HTTP server.
      //
      // **On by default** in the desktop app, bound to loopback (127.0.0.1).
      // External services can fire automations by POSTing to
      // /v1/triggers/<workspaceId>/<slug>.
      //
      // Override behavior:
      //   CRAFT_TRIGGER_PORT=0           → disable
      //   CRAFT_TRIGGER_PORT=NNNN        → use NNNN instead of the default
      //   CRAFT_TRIGGER_HOST=0.0.0.0     → bind to all interfaces (only safe
      //                                    behind a tunnel + with HMAC enabled)
      //
      // Loopback binding makes auto-start safe — outsiders can't reach the
      // port. Users who want public exposure must explicitly bind to 0.0.0.0.
      // -----------------------------------------------------------------------
      try {
        const DEFAULT_TRIGGER_PORT = RUNTIME_IDENTITY.defaultTriggerPort
        const envPort = process.env.CRAFT_TRIGGER_PORT
        let triggerPort: number
        if (envPort === undefined || envPort === '') {
          triggerPort = DEFAULT_TRIGGER_PORT
        } else {
          const parsed = parseInt(envPort, 10)
          // Negative → disable. NaN → fall back to default.
          triggerPort = Number.isNaN(parsed) ? DEFAULT_TRIGGER_PORT : parsed
        }
        if (triggerPort > 0) {
          const { startTriggerHttpServer } = await import('@craft-agent/server-core/triggers')
          triggerServerHandle = await startTriggerHttpServer({
            port: triggerPort,
            host: process.env.CRAFT_TRIGGER_HOST ?? '127.0.0.1',
            resolver: instance.sessionManager,
            logger: {
              info: (m, ...a) => mainLog.info(m, ...a),
              warn: (m, ...a) => mainLog.warn(m, ...a),
              error: (m, ...a) => mainLog.error(m, ...a),
            },
          })
          if (triggerServerHandle) {
            mainLog.info(`[trigger-server] Listening on ${triggerServerHandle.url}`)
          }
        } else {
          mainLog.info('[trigger-server] Disabled (CRAFT_TRIGGER_PORT=0)')
        }
      } catch (err) {
        // Most likely cause: port already in use. Don't crash — webhook
        // automations simply won't fire until the port is free or the user
        // sets CRAFT_TRIGGER_PORT to a different value.
        mainLog.error('[trigger-server] Failed to start:', err)
      }

      // -----------------------------------------------------------------------
      // Messaging Gateway — attach the WS publisher, init local workspaces,
      // install the fan-out event sink. The handle was created inside
      // createHandlerDeps so the registry could be wired into HandlerDeps.
      // -----------------------------------------------------------------------
      try {
        if (!messagingHandle) {
          throw new Error('Messaging handle was not constructed in createHandlerDeps')
        }

        messagingHandle.setPublisher(instance.wsServer.push.bind(instance.wsServer))

        // Skip remote-owned workspaces — messaging runs on the remote server.
        const localWorkspaceIds = getWorkspaces()
          .filter((ws) => !ws.remoteServer)
          .map((ws) => ws.id)
        await messagingHandle.initializeWorkspaces(localWorkspaceIds)

        // Compose fan-out event sink: RPC push + messaging gateway dispatch.
        // Always install — this lets workspaces enable messaging at runtime
        // without a process restart.
        const baseSink = instance.wsServer.push.bind(instance.wsServer)
        instance.sessionManager.setEventSink(messagingHandle.wrapSink(baseSink))
        if (messagingHandle.registry.size > 0) {
          mainLog.info(`[messaging] Fan-out sink active for ${messagingHandle.registry.size} workspace(s)`)
        }
      } catch (err) {
        mainLog.error('[messaging] Gateway initialization failed:', err)
      }

      // IPC handlers — preload uses sendSync to get WS connection details

      const { createCampaignCleanupController } = await import('./campaign-cleanup')
      const campaignCleanup = createCampaignCleanupController({
        runtime: instance.sessionManager,
        acquireRequestFence: () => instance.wsServer.acquireCampaignCleanupFence(),
        stopMessaging: async (workspaceId) => { await messagingHandle?.registry.removeWorkspace(workspaceId) },
        resumeMessaging: async (workspaceId) => { await messagingHandle?.initializeWorkspaces([workspaceId]) },
        onDeleted: (result) => {
          const hq = getWorkspaces().find((workspace) => workspace.id === result.hqWorkspaceId)
          if (hq) {
            void import('@craft-agent/server-core').then(({ scheduleHqStateContextRefresh }) => scheduleHqStateContextRefresh(hq.rootPath))
          }
          for (const managed of windowManager?.getAllWindows() ?? []) {
            if (!managed.window.isDestroyed()) managed.window.webContents.send('campaign:deleted', { workspaceId: result.workspaceId, hqWorkspaceId: result.hqWorkspaceId })
          }
        },
      })
      ipcMain.handle('campaign:cleanupPreview', async (_event, workspaceId: string) => {
        assertProductLicensedChannel('campaign:cleanupPreview')
        return campaignCleanup.preview(workspaceId)
      })
      ipcMain.handle('campaign:delete', async (_event, workspaceId: string, previewToken: string) => {
        assertProductLicensedChannel('campaign:delete')
        return campaignCleanup.delete(workspaceId, previewToken)
      })

      // Remove workspace from config (cleanup stale entries)
      ipcMain.handle('workspace:remove', async (_event, workspaceId: string) => {
        assertProductLicensedChannel('workspace:remove')
        const { getWorkspaceByNameOrId, getWorkspaces, removeWorkspace: remove } = await import('@craft-agent/shared/config')
        const removedWorkspace = getWorkspaceByNameOrId(workspaceId)
        const hqRootPath = getWorkspaces().find((workspace) => workspace.artistWorkspaceScope === 'hq')?.rootPath
        const removed = await remove(workspaceId)
        if (removed && removedWorkspace?.artistWorkspaceScope === 'campaign' && hqRootPath) {
          const { scheduleHqStateContextRefresh } = await import('@craft-agent/server-core')
          scheduleHqStateContextRefresh(hqRootPath)
        }
        return removed
      })

      // Cross-server RPC — invoke a channel on an arbitrary remote server
      ipcMain.handle('server:invokeOnServer', async (_event, url: string, token: string, channel: string, ...args: unknown[]) => {
        assertProductLicensedChannel(channel)
        const { connectToRemote } = await import('./handlers/workspace')
        const { client, error } = await connectToRemote(url, token)
        if (!client) throw new Error(error ?? 'Connection failed')
        try {
          return await client.invoke(channel, ...args)
        } finally {
          client.destroy()
        }
      })

      // Transfer session to another workspace — orchestrated in main process
      // so large bundles can be moved directly between owning servers.
      ipcMain.handle('session:transferToRemoteWorkspace', async (_event, sessionId: string, targetWorkspaceId: string, sessionIndex?: number, sessionCount?: number) => {
        assertProductLicensedChannel('session:transferToRemoteWorkspace')
        const idx = sessionIndex ?? 0
        const count = sessionCount ?? 1
        const { getWorkspaceByNameOrId } = await import('@craft-agent/shared/config')
        const { connectToRemote } = await import('./handlers/workspace')
        const { CHUNKED_TRANSFER_THRESHOLD, getChunkCount, invokeChunked, prepareChunkedPayload } = await import('./chunked-rpc')

        const targetWorkspace = getWorkspaceByNameOrId(targetWorkspaceId)
        if (!targetWorkspace?.remoteServer) throw new Error(`Workspace ${targetWorkspaceId} has no remote server`)
        if (!sessionManager) throw new Error('Session manager not initialized')

        const sourceWorkspaceLocalId = windowManager?.getWorkspaceForWindow(_event.sender.id)
        if (!sourceWorkspaceLocalId) throw new Error('Unable to resolve source workspace for transfer')

        const sourceWorkspace = getWorkspaceByNameOrId(sourceWorkspaceLocalId)
        if (!sourceWorkspace) throw new Error(`Source workspace ${sourceWorkspaceLocalId} not found`)

        let bundle: any = null

        if (sourceWorkspace.remoteServer) {
          const { url: sourceUrl, token: sourceToken, remoteWorkspaceId: sourceRemoteWorkspaceId } = sourceWorkspace.remoteServer
          console.log(`[Transfer] Exporting remote-owned session ${sessionId} from workspace ${sourceRemoteWorkspaceId}...`)
          const { client: sourceClient, error: sourceError } = await connectToRemote(sourceUrl, sourceToken, sourceRemoteWorkspaceId)
          if (!sourceClient) throw new Error(sourceError ?? 'Connection failed to source remote server')

          try {
            bundle = await sourceClient.invoke('sessions:export', sessionId)
            if (!bundle) throw new Error(`Failed to export session ${sessionId}`)

            try {
              console.log('[Transfer] Generating conversation summary on source server...')
              const transferPayload = await sourceClient.invoke('sessions:exportRemoteTransfer', sessionId)
              if (transferPayload?.summary && bundle.session?.header) {
                ;(bundle.session.header as any).transferredSessionSummary = transferPayload.summary
                ;(bundle.session.header as any).transferredSessionSummaryApplied = false
                console.log(`[Transfer] Summary generated: ${transferPayload.summary.length} chars`)
              }
            } catch (err) {
              console.warn('[Transfer] Source-server summary generation failed:', err)
            }
          } finally {
            sourceClient.destroy()
          }
        } else {
          console.log(`[Transfer] Exporting local-owned session ${sessionId} from workspace ${sourceWorkspace.id}...`)
          bundle = await sessionManager.exportSession(sessionId, sourceWorkspace.id)
          if (!bundle) throw new Error(`Failed to export session ${sessionId}`)

          try {
            console.log('[Transfer] Generating conversation summary...')
            const transferPayload = await sessionManager.exportRemoteSessionTransfer(sessionId, sourceWorkspace.id)
            if (transferPayload?.summary && bundle.session?.header) {
              ;(bundle.session.header as any).transferredSessionSummary = transferPayload.summary
              ;(bundle.session.header as any).transferredSessionSummaryApplied = false
              console.log(`[Transfer] Summary generated: ${transferPayload.summary.length} chars`)
            }
          } catch (err) {
            console.warn('[Transfer] Summary generation failed:', err)
          }
        }

        console.log(`[Transfer] Export complete: ${bundle.session?.messages?.length ?? 0} messages, ${bundle.files?.length ?? 0} files`)

        const { url, token, remoteWorkspaceId } = targetWorkspace.remoteServer
        console.log(`[Transfer] Connecting to target remote server: ${url}`)
        const { client, error } = await connectToRemote(url, token, remoteWorkspaceId)
        if (!client) throw new Error(error ?? 'Connection failed to target remote server')
        console.log('[Transfer] Connected to target remote server')

        try {
          const preparedBundle = prepareChunkedPayload(bundle)
          const payloadSize = preparedBundle.bytes.length
          const payloadMB = (payloadSize / (1024 * 1024)).toFixed(1)

          const emitProgress = (chunkSent: number, chunkTotal: number) => {
            try { _event.sender.send('transfer:progress', { sessionIndex: idx, sessionCount: count, chunkSent, chunkTotal }) } catch { /* renderer may be gone */ }
          }

          if (payloadSize < CHUNKED_TRANSFER_THRESHOLD) {
            console.log(`[Transfer] Bundle size: ${payloadMB}MB (< 5MB threshold) → using direct RPC`)
            emitProgress(0, 1)
            const result = await client.invoke('sessions:import', remoteWorkspaceId, bundle, 'fork')
            emitProgress(1, 1)
            return result
          }

          const chunkCount = getChunkCount(payloadSize)
          console.log(`[Transfer] Bundle size: ${payloadMB}MB (>= 5MB threshold) → using chunked transfer (${chunkCount} chunks)`)
          return await invokeChunked(
            client,
            'sessions:import',
            [remoteWorkspaceId, bundle, 'fork'],
            1,
            emitProgress,
            preparedBundle,
          )
        } finally {
          client.destroy()
        }
      })

      // App relaunch (for server config changes — NOT an update install)
      ipcMain.handle('app:relaunch', createSafeRelaunch({
        prepare: () => {
          isQuitting = true
          windowManager?.setAppQuitting(true)
          captureAndSaveWindowState('before-quit')
        },
        cleanup: waitForQuitCleanup,
        relaunch: () => app.relaunch(),
        exit: () => app.exit(0),
        failed: () => {
          isQuitting = false
          windowManager?.setAppQuitting(false)
        },
      }))

      // Language change: sync from renderer to main process and rebuild native menu
      ipcMain.handle('i18n:changeLanguage', async (_event, lang: string) => {
        i18n.changeLanguage(lang)
        const { rebuildMenu } = await import('./menu')
        await rebuildMenu()
      })

      ipcMain.on('__get-ws-port', (e) => {
        e.returnValue = instance.port
      })
      ipcMain.on('__get-ws-token', (e) => {
        e.returnValue = instance.token
      })
      ipcMain.on('__get-workspace-remote-config', (e) => {
        const wsId = windowManager?.getWorkspaceForWindow(e.sender.id)
        if (!wsId) { e.returnValue = null; return }
        const ws = getWorkspaceByNameOrId(wsId)
        e.returnValue = ws?.remoteServer ?? null
      })

      // Server config RPC handlers (LOCAL_ONLY — Electron-specific)
      const runningServerState = {
        host: rpcHost,
        port: instance.port,
        tls: !!tls,
        token: serverToken,
        enabled: serverModeEnabled,
      }

      instance.wsServer.handle(RPC_CHANNELS.settings.GET_SERVER_CONFIG, async () => {
        const { getServerConfig: getConfig } = await import('@craft-agent/shared/config')
        return getConfig()
      })

      instance.wsServer.handle(RPC_CHANNELS.settings.SET_SERVER_CONFIG, async (_ctx: unknown, config: unknown) => {
        const { setServerConfig: setConfig } = await import('@craft-agent/shared/config')
        const cfg = config as import('@craft-agent/shared/config/server-config').ServerConfig
        // Validate port range
        if (cfg.port < 1024 || cfg.port > 65535) {
          throw new Error(`Port must be between 1024 and 65535, got ${cfg.port}`)
        }
        // Validate cert/key files exist if provided
        if (cfg.tlsCertPath && !existsSync(cfg.tlsCertPath)) {
          throw new Error(`Certificate file not found: ${cfg.tlsCertPath}`)
        }
        if (cfg.tlsKeyPath && !existsSync(cfg.tlsKeyPath)) {
          throw new Error(`Private key file not found: ${cfg.tlsKeyPath}`)
        }
        setConfig(cfg)
      })

      instance.wsServer.handle(RPC_CHANNELS.settings.GET_SERVER_STATUS, async () => {
        const { getServerConfig: getConfig } = await import('@craft-agent/shared/config')
        const saved = getConfig()
        const protocol = runningServerState.tls ? 'wss' : 'ws'

        // Determine display host (LAN IP if bound to 0.0.0.0)
        let displayHost = runningServerState.host
        if (displayHost === '0.0.0.0' || displayHost === '::') {
          const os = await import('os')
          const nets = os.networkInterfaces()
          for (const name of Object.keys(nets)) {
            for (const net of nets[name] ?? []) {
              if (net.family === 'IPv4' && !net.internal) {
                displayHost = net.address
                break
              }
            }
            if (displayHost !== '0.0.0.0' && displayHost !== '::') break
          }
        }

        // Only compare port/tls/token when at least one side has server mode enabled.
        // When both are disabled, the running port is random — comparing it to the
        // saved default (9100) would always produce a false "restart required" banner.
        const needsRestart = saved.enabled !== runningServerState.enabled
          || ((saved.enabled || runningServerState.enabled) && (
            saved.port !== runningServerState.port
            || (!!saved.tlsCertPath) !== runningServerState.tls
            || (saved.token ?? '') !== runningServerState.token
          ))

        return {
          running: true,
          host: runningServerState.host,
          port: runningServerState.port,
          tls: runningServerState.tls,
          url: `${protocol}://${displayHost}:${runningServerState.port}`,
          token: runningServerState.token,
          needsRestart,
          insecureWarning: isInsecureBind,
        }
      })

      // TLS enforcement — warn when server mode binds to a network address without TLS
      // Mirrors the hard guard in packages/server/src/index.ts but warns instead of blocking,
      // since the user explicitly enabled server mode via UI (may be on a trusted LAN).
      const isInsecureBind = serverModeEnabled && !tls
        && !['127.0.0.1', 'localhost', '::1'].includes(rpcHost)
      if (isInsecureBind) {
        mainLog.warn(
          '[server-mode] WARNING: Listening on a network address without TLS. ' +
          'Auth tokens will be sent in cleartext. ' +
          'Configure TLS certificates in Settings > Server.'
        )
      }

      // Wire EventSink to Electron-specific services
      // Must happen BEFORE createInitialWindows() so event handlers use WS from the start
      windowManager.setRpcEventSink(moduleSink!, resolveClientId)
      const { setMenuEventSink } = await import('./menu')
      setMenuEventSink(moduleSink!, resolveClientId)
      const { setNotificationEventSink } = await import('./notifications')
      setNotificationEventSink(moduleSink!, resolveClientId)

      // Headless: print connection details
      if (isHeadless) {
        console.log(`CRAFT_SERVER_URL=${instance.protocol}://${instance.host}:${instance.port}`)
        console.log(`CRAFT_SERVER_TOKEN=${instance.token}`)
      }
    }

    // Create initial windows (restores from saved state or opens first workspace)
    // In headless mode the server runs without any UI — skip window creation.
    if (!isHeadless) {
      await createInitialWindows()
    }

    // Run credential health check at startup to detect issues early
    // (corruption, machine migration, missing credentials for default connection)
    // Skip in thin-client mode — credentials are managed by the remote server.
    if (!isClientOnly) {
      try {
        const { getCredentialManager } = await import('@craft-agent/shared/credentials')
        const credentialManager = getCredentialManager()
        const health = await credentialManager.checkHealth()
        if (!health.healthy) {
          mainLog.warn('Credential health check failed:', health.issues)
          // Issues will be displayed in Settings → AI when user navigates there
        }
      } catch (err) {
        mainLog.error('Credential health check error:', err)
      }
    }

    // Initialize power manager (loads setting, must happen after config is available)
    // Non-critical — powerSaveBlocker may not work on headless/xvfb setups
    try {
      const { initPowerManager } = await import('./power-manager')
      await initPowerManager()
    } catch (err) {
      mainLog.warn('[power] Power manager init failed (non-critical):', err instanceof Error ? err.message : err)
    }

    // Set Sentry context tags for error grouping (no PII — just config classification).
    // Runs after init so config and auth state are available.
    // Derives values from the default LLM connection instead of legacy config fields.
    try {
      const { getLlmConnection, getDefaultLlmConnection } = await import('@craft-agent/shared/config')
      const workspaces = getWorkspaces()
      const defaultConnSlug = getDefaultLlmConnection()
      const defaultConn = defaultConnSlug ? getLlmConnection(defaultConnSlug) : null
      Sentry.setTag('authType', defaultConn?.authType ?? 'unknown')
      Sentry.setTag('providerType', defaultConn?.providerType ?? 'unknown')
      Sentry.setTag('hasCustomEndpoint', String(!!defaultConn?.baseUrl))
      Sentry.setTag('model', defaultConn?.defaultModel ?? 'default')
      Sentry.setTag('workspaceCount', String(workspaces.length))
    } catch (err) {
      mainLog.warn('Failed to set Sentry context tags:', err)
    }

    // Initialize auto-update (check immediately on launch)
    // Skip in dev mode to avoid replacing /Applications app and launching it instead
    if (moduleSink) setAutoUpdateEventSink(moduleSink)
    setBeforeUpdateQuitHook(() => captureAndSaveWindowState('pre-update'))
    setBeforeUpdateInstallHook(async () => {
      isQuitting = true
      windowManager?.setAppQuitting(true)
      try { await waitForQuitCleanup() }
      catch (error) { isQuitting = false; windowManager?.setAppQuitting(false); throw error }
    })
    setInstallQuitFailedHook(() => {
      mainLog.error('[auto-update] install handoff failed after cleanup — relaunching')
      dialog.showMessageBoxSync({
        type: 'error',
        title: 'Update failed',
        message: 'The update could not be installed.',
        detail: `${RUNTIME_IDENTITY.productName} will restart now and retry on the next launch.`,
      })
      app.relaunch()
      app.exit(0)
    })
    if (app.isPackaged) {
      checkForUpdatesOnLaunch().catch(err => {
        mainLog.error('[auto-update] Launch check failed:', err)
      })
    } else {
      mainLog.info('[auto-update] Skipping auto-update in dev mode')
    }

    // Process pending deep link from cold start
    if (pendingDeepLink) {
      mainLog.info('Processing pending deep link:', pendingDeepLink)
      await handleDeepLink(pendingDeepLink, windowManager, moduleSink ?? undefined, moduleClientResolver ?? undefined)
      pendingDeepLink = null
    }

    mainLog.info('App initialized successfully')
    if (isDebugMode) {
      mainLog.info('Debug mode enabled - logs at:', getLogFilePath())
    }
    mainLog.info('Messaging gateway log path:', getMessagingGatewayLogFilePath())
  } catch (error) {
    mainLog.error('Failed to initialize app:', error instanceof Error ? error.message : error, (error as any)?.stack)
    // Continue anyway - the app will show errors in the UI
  }

  // macOS: Re-create window when dock icon is clicked
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0 && windowManager) {
      // Open first workspace or last focused
      const workspaces = getWorkspaces()
      const artistStartup = artistStartupWindow(RUNTIME_IDENTITY.variant, workspaces)
      if (artistStartup) {
        windowManager.createWindow(artistStartup)
        return
      }
      if (workspaces.length > 0) {
        const savedState = loadWindowState()
        const wsId = savedState?.lastFocusedWorkspaceId || workspaces[0].id
        // Verify workspace still exists
        if (workspaces.some(ws => ws.id === wsId)) {
          windowManager.createWindow({ workspaceId: wsId })
        } else {
          windowManager.createWindow({ workspaceId: workspaces[0].id })
        }
      }
    }
  })
})

app.on('window-all-closed', () => {
  if (process.env.CRAFT_HEADLESS) return  // headless server stays alive
  // On macOS, apps typically stay active until explicitly quit
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

// Track if we're in the process of quitting (to avoid re-entry)
let isQuitting = false

function captureAndSaveWindowState(reason: 'before-quit' | 'pre-update'): number {
  if (!windowManager) return 0
  const windows = windowManager.getWindowStates()
  const focusedWindow = BrowserWindow.getFocusedWindow()
  const lastFocusedWorkspaceId = focusedWindow
    ? windowManager.getWorkspaceForWindow(focusedWindow.webContents.id) ?? undefined
    : undefined
  saveWindowState({ windows, lastFocusedWorkspaceId })
  mainLog.info(`[window-state] Saved ${windows.length} window(s) during ${reason}`)
  return windows.length
}

let shutdownNotice: Promise<void> | undefined
function showShutdownWaiting(): Promise<void> {
  if (shutdownNotice) return shutdownNotice
  const notice = dialog.showMessageBox({
    type: 'info', title: 'Finishing active work',
    message: `${RUNTIME_IDENTITY.productName} is still waiting for active work to stop safely.`,
    detail: 'Your work and storage remain open while this finishes. Quit or update will continue automatically when it is safe. Choose Quit again to check the status.',
    buttons: ['Keep waiting'], defaultId: 0, cancelId: 0,
  }).then(() => {})
  shutdownNotice = notice
  void notice.finally(() => { if (shutdownNotice === notice) shutdownNotice = undefined }).catch(() => {})
  return notice
}
function waitForQuitCleanup(): Promise<void> {
  return waitForSafeShutdown(performQuitCleanup(), { waitMs: 15_000, onWaiting: showShutdownWaiting })
}

let quitCleanupRan = false
let quitCleanupComplete = false
let quitCleanupAttempt: Promise<void> | undefined
function performQuitCleanup(): Promise<void> {
  if (quitCleanupAttempt) return quitCleanupAttempt
  const attempt = runQuitCleanup()
  quitCleanupAttempt = attempt
  void attempt.catch(() => { if (quitCleanupAttempt === attempt) quitCleanupAttempt = undefined })
  return attempt
}
async function runQuitCleanup(): Promise<void> {
  if (quitCleanupRan) {
    mainLog.info('Quit cleanup already ran, skipping')
    return
  }
  // Do not tear down execution dependencies until the durable journal drains.
  await electronDurableWorkflowLifetime.close()
  quitCleanupRan = true

  if (artistManagerMoonshine) {
    try { await artistManagerMoonshine.close() }
    catch (error) { mainLog.error('[moonshine] cleanup failed:', error) }
    artistManagerMoonshine = null
  }

  if (embeddedOmniRoute) {
    try { await embeddedOmniRoute.stop() }
    catch (error) { mainLog.error('[omniroute] cleanup failed:', error) }
    embeddedOmniRoute = null
  }

  if (sessionManager) {
    try {
      await sessionManager.flushAllSessions()
      mainLog.info('Flushed all pending session writes')
    } catch (error) {
      mainLog.error('Failed to flush sessions:', error)
    }
    sessionManager.cleanup()
  }

  browserPaneManager?.destroyAll()
  oauthFlowStore?.dispose()
  getModelRefreshService().stopAll()

  if (triggerServerHandle) {
    try {
      await triggerServerHandle.stop()
    } catch (error) {
      mainLog.error('[trigger-server] stop failed:', error)
    }
  }

  if (artistManagerVoiceProxy) {
    artistManagerVoiceFocus.close()
    try {
      await artistManagerVoiceProxy.close()
      artistManagerVoiceProxy = null
    } catch (error) {
      mainLog.error('[artist-manager-voice] cleanup failed:', error)
    }
  }

  if (messagingHandle) {
    try {
      await messagingHandle.dispose()
    } catch (error) {
      mainLog.error('[messaging] dispose failed:', error)
    }
  }

  const { cleanup: cleanupPowerManager } = await import('./power-manager')
  cleanupPowerManager()
  releaseServerLock()
  quitCleanupComplete = true
}

// Save window state and clean up resources before quitting
app.on('before-quit', async (event) => {
  // Avoid re-entry when we call app.exit()
  if (isQuitting && quitCleanupComplete) return
  event.preventDefault()
  if (isQuitting) { void showShutdownWaiting().catch(() => {}); return }
  isQuitting = true

  // Ensure Cmd+Q/app quit bypasses layered window close interception (Cmd+W behavior).
  windowManager?.setAppQuitting(true)

  captureAndSaveWindowState('before-quit')
  try {
    await waitForQuitCleanup()
    app.exit(0)
  } catch (error) {
    mainLog.error('Quit cleanup failed; quit can be retried:', error)
    isQuitting = false
    windowManager?.setAppQuitting(false)
    const choice = await dialog.showMessageBox({
      type: 'warning', title: 'Could not finish quitting',
      message: `${RUNTIME_IDENTITY.productName} could not finish stopping active work safely.`,
      detail: 'The app has not forced storage closed. Retry when the connection or storage is available.',
      buttons: ['Retry quit', 'Keep app open'], defaultId: 0, cancelId: 1,
    })
    if (choice.response === 0) app.quit()
  }
})

// Handle uncaught exceptions — forward to Sentry explicitly since registering
// a custom handler can interfere with @sentry/electron's automatic capture.
process.on('uncaughtException', (error) => {
  mainLog.error('Uncaught exception:', error)
  Sentry.captureException(error)
})

process.on('unhandledRejection', (reason, promise) => {
  mainLog.error('Unhandled rejection at:', promise, 'reason:', reason)
  Sentry.captureException(reason instanceof Error ? reason : new Error(String(reason)))
})
