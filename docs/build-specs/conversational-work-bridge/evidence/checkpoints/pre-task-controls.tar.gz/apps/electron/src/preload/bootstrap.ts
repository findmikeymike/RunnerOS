/**
 * WS-mode preload — replaces the full IPC preload (index.ts).
 *
 * Normal mode (local server):
 *   Creates a RoutedClient that routes LOCAL_ONLY channels to the local
 *   Electron server and REMOTE_ELIGIBLE channels to whichever server owns
 *   the active workspace (local or remote). Workspace switches swap the
 *   workspace client transparently.
 *
 * Thin-client mode (CRAFT_SERVER_URL):
 *   Creates a single WsRpcClient connected to the remote server.
 *   All channels go to the remote server.
 *
 * On localhost the WS handshake completes in <1ms. The React app takes >100ms
 * to initialise, so by the time any component calls an API method, the
 * connection is established.
 */

import '@sentry/electron/preload'
import { contextBridge, ipcRenderer, shell, webUtils } from 'electron'
import { WsRpcClient, type TransportConnectionState } from '../transport/client'
import { RoutedClient } from '../transport/routed-client'
import { buildClientApi } from '../transport/build-api'
import { CHANNEL_MAP } from '../transport/channel-map'
import { createCallbackServer, validateOAuthCallback } from '@craft-agent/shared/auth/callback-server'
import { CHATGPT_OAUTH_CONFIG } from '@craft-agent/shared/auth/chatgpt-oauth-config'
import {
  CLIENT_OPEN_EXTERNAL,
  CLIENT_OPEN_PATH,
  CLIENT_SHOW_IN_FOLDER,
  CLIENT_CONFIRM_DIALOG,
  CLIENT_OPEN_FILE_DIALOG,
  LOCAL_CLIENT_CAPABILITIES,
} from '@craft-agent/server-core/transport'
import type { ConfirmDialogSpec, FileDialogSpec } from '@craft-agent/server-core/transport'
import type { RpcClient } from '@craft-agent/server-core/transport'
import type { RemoteServerConfig } from '@craft-agent/core/types'
import type { ElectronAPI } from '../shared/types'
import type { ArtistOSActivateInputV1, ArtistOSLicenseSnapshotV1 } from '@craft-agent/shared/licensing'

// ---------------------------------------------------------------------------
// Client interface — common surface for both RoutedClient and WsRpcClient
// ---------------------------------------------------------------------------

interface TransportClient extends RpcClient {
  isChannelAvailable(channel: string): boolean
  getConnectionState(): TransportConnectionState
  onConnectionStateChanged(callback: (state: TransportConnectionState) => void): () => void
  reconnectNow(): void
}

class LicensedTransportClient implements TransportClient {
  constructor(private readonly inner: TransportClient) {}
  async invoke(channel: string, ...args: any[]): Promise<any> {
    await ipcRenderer.invoke('__license:authorize-channel', channel)
    return await this.inner.invoke(channel, ...args)
  }
  on(channel: string, callback: (...args: any[]) => void): () => void { return this.inner.on(channel, callback) }
  handleCapability(channel: string, handler: (...args: any[]) => Promise<any> | any): void { this.inner.handleCapability(channel, handler) }
  isChannelAvailable(channel: string): boolean { return this.inner.isChannelAvailable(channel) }
  getConnectionState(): TransportConnectionState { return this.inner.getConnectionState() }
  onConnectionStateChanged(callback: (state: TransportConnectionState) => void): () => void { return this.inner.onConnectionStateChanged(callback) }
  reconnectNow(): void { this.inner.reconnectNow() }
}

// ---------------------------------------------------------------------------
// Connection setup
// ---------------------------------------------------------------------------

const webContentsId: number = ipcRenderer.sendSync('__get-web-contents-id')
const isClientOnly = !!process.env.CRAFT_SERVER_URL
const productVariant = process.env.CRAFT_PRODUCT_VARIANT === 'artist-os' ? 'artist-os' : 'runner'

let client: TransportClient

if (isClientOnly) {
  // ── Thin-client mode ───────────────────────────────────────────────────
  // Single WsRpcClient connected directly to the remote server.
  // No local server, no routing — all channels go to remote.

  const wsUrl = process.env.CRAFT_SERVER_URL!
  const wsToken = process.env.CRAFT_SERVER_TOKEN ?? ''

  // Block unencrypted ws:// to non-localhost servers — tokens would be sent in cleartext
  const parsed = new URL(wsUrl)
  const isLocalhost = parsed.hostname === 'localhost' || parsed.hostname === '127.0.0.1' || parsed.hostname === '::1'
  if (parsed.protocol === 'ws:' && !isLocalhost) {
    throw new Error(
      `Refusing to connect to remote server over unencrypted ws://. ` +
      `Use wss:// (TLS) for non-localhost connections. ` +
      `Set CRAFT_RPC_TLS_CERT/KEY on the server to enable TLS.`
    )
  }

  // Workspace ID is optional — if missing, renderer shows a workspace picker
  const workspaceId = process.env.CRAFT_WORKSPACE_ID || ipcRenderer.sendSync('__get-workspace-id') || undefined

  const wsClient = new WsRpcClient(wsUrl, {
    token: wsToken,
    productVariant,
    workspaceId,
    webContentsId,
    autoReconnect: true,
    mode: 'remote',
    requestTimeout: 90_000,
    clientCapabilities: [...LOCAL_CLIENT_CAPABILITIES],
  })
  wsClient.connect()
  client = wsClient

} else {
  // ── Normal mode ────────────────────────────────────────────────────────
  // RoutedClient routes LOCAL_ONLY to local server, REMOTE_ELIGIBLE to
  // whichever server owns the workspace (local or remote).

  const wsPort: number = ipcRenderer.sendSync('__get-ws-port')
  const wsToken: string = ipcRenderer.sendSync('__get-ws-token')
  const workspaceId: string = ipcRenderer.sendSync('__get-workspace-id')

  const localClient = new WsRpcClient(`ws://127.0.0.1:${wsPort}`, {
    token: wsToken,
    productVariant,
    workspaceId,
    webContentsId,
    autoReconnect: true,
    mode: 'local',
    requestTimeout: 90_000,
    clientCapabilities: [...LOCAL_CLIENT_CAPABILITIES],
  })

  // Check if the current workspace is remote (synchronous IPC during preload eval)
  const remoteConfig: RemoteServerConfig | null = ipcRenderer.sendSync('__get-workspace-remote-config')

  let initialWorkspaceClient: WsRpcClient
  if (remoteConfig && typeof remoteConfig.url === 'string') {
    // Workspace is remote — create a direct connection to the remote server
    initialWorkspaceClient = new WsRpcClient(remoteConfig.url, {
      token: remoteConfig.token,
      productVariant,
      workspaceId: remoteConfig.remoteWorkspaceId,
      webContentsId,
      autoReconnect: true,
      mode: 'remote',
      requestTimeout: 90_000,
      clientCapabilities: [...LOCAL_CLIENT_CAPABILITIES],
      // Validate the remote server's certificate. Set CRAFT_INSECURE_TLS=1 to
      // accept self-signed certs — a deliberate, per-machine opt-out rather than
      // the silent default it used to be.
      tlsRejectUnauthorized: process.env.CRAFT_INSECURE_TLS !== '1',
    })
    initialWorkspaceClient.connect()
  } else {
    // Workspace is local — workspace client IS the local client
    initialWorkspaceClient = localClient
  }

  const routedClient = new RoutedClient(localClient, initialWorkspaceClient)

  // Set workspace ID mapping if initial workspace is remote
  if (remoteConfig) {
    routedClient.setWorkspaceMapping(workspaceId, remoteConfig.remoteWorkspaceId)
  }

  // Factory for creating remote workspace clients on switch
  routedClient.setClientFactory((remoteServer: RemoteServerConfig) => {
    return new WsRpcClient(remoteServer.url, {
      token: remoteServer.token,
      productVariant,
      workspaceId: remoteServer.remoteWorkspaceId,
      webContentsId,
      autoReconnect: true,
      mode: 'remote',
      requestTimeout: 90_000,
      clientCapabilities: [...LOCAL_CLIENT_CAPABILITIES],
      // Validate the remote server's certificate. Set CRAFT_INSECURE_TLS=1 to
      // accept self-signed certs — a deliberate, per-machine opt-out rather than
      // the silent default it used to be.
      tlsRejectUnauthorized: process.env.CRAFT_INSECURE_TLS !== '1',
    })
  })

  localClient.connect()
  client = routedClient
}

// ---------------------------------------------------------------------------
// Register client-side capability handlers (server can invoke these)
// ---------------------------------------------------------------------------

client.handleCapability(CLIENT_OPEN_EXTERNAL, async (url: string) => {
  const { isSafeExternalUrl } = await import('@craft-agent/shared/utils/url-safety')
  if (!isSafeExternalUrl(url)) {
    throw new Error('Blocked unsafe external URL')
  }
  return shell.openExternal(url)
})

client.handleCapability(CLIENT_OPEN_PATH, async (path: string) => {
  const error = await shell.openPath(path)
  return { error: error || undefined }
})

client.handleCapability(CLIENT_SHOW_IN_FOLDER, (path: string) => {
  shell.showItemInFolder(path)
})

client.handleCapability(CLIENT_CONFIRM_DIALOG, async (spec: ConfirmDialogSpec) => {
  return await ipcRenderer.invoke('__dialog:showMessageBox', spec)
})

client.handleCapability(CLIENT_OPEN_FILE_DIALOG, async (spec: FileDialogSpec) => {
  return await ipcRenderer.invoke('__dialog:showOpenDialog', spec)
})

// ---------------------------------------------------------------------------
// Build ElectronAPI proxy
// ---------------------------------------------------------------------------

const authorizedClient: TransportClient = productVariant === 'artist-os'
  ? new LicensedTransportClient(client)
  : client
const api = buildClientApi(authorizedClient, CHANNEL_MAP, (ch) => authorizedClient.isChannelAvailable(ch))

;(api as any).getRuntimeEnvironment = (): 'electron' | 'web' => 'electron'
;(api as any).webContentsId = webContentsId

// ---------------------------------------------------------------------------
// Transport connection state logging (for remote connections)
// ---------------------------------------------------------------------------

function formatTransportReason(state: TransportConnectionState): string {
  const err = state.lastError
  if (err) {
    const codePart = err.code ? ` [${err.code}]` : ''
    return `${err.kind}${codePart}: ${err.message}`
  }

  if (state.lastClose?.code != null) {
    const reason = state.lastClose.reason ? ` (${state.lastClose.reason})` : ''
    return `close ${state.lastClose.code}${reason}`
  }

  return 'no additional details'
}

// Log remote connection state changes to main process (visible in terminal + main.log).
// Activates whenever the workspace connection is remote (thin client or remote workspace).
client.onConnectionStateChanged((state) => {
  if (state.mode !== 'remote') return

  const emitToMain = (level: 'info' | 'warn' | 'error', message: string) => {
    ipcRenderer.send('__transport:status', {
      level,
      message,
      status: state.status,
      attempt: state.attempt,
      nextRetryInMs: state.nextRetryInMs,
      error: state.lastError,
      close: state.lastClose,
      url: state.url,
    })
  }

  if (state.status === 'connected') {
    const message = `[transport] connected to ${state.url}`
    console.info(message)
    emitToMain('info', message)
    return
  }

  if (state.status === 'reconnecting') {
    const retry = state.nextRetryInMs != null ? ` retry in ${state.nextRetryInMs}ms` : ''
    const message = `[transport] reconnecting (attempt ${state.attempt})${retry} — ${formatTransportReason(state)}`
    console.warn(message)
    emitToMain('warn', message)
    return
  }

  if (state.status === 'failed' || state.status === 'disconnected') {
    const message = `[transport] ${state.status} — ${formatTransportReason(state)}`
    console.error(message)
    emitToMain('error', message)
  }
})

// ---------------------------------------------------------------------------
// Transport state API (exposed to renderer)
// ---------------------------------------------------------------------------

;(api as any).getTransportConnectionState = async () => client.getConnectionState()
;(api as any).onTransportConnectionStateChanged = (callback: (state: TransportConnectionState) => void) => {
  return client.onConnectionStateChanged(callback)
}
;(api as any).reconnectTransport = async () => {
  client.reconnectNow()
}

// ── performOAuth ─────────────────────────────────────────────────────────
// Multi-step orchestration: callback server (local) → oauth:start (server) →
// open browser → wait for callback → oauth:complete (server).
// Runs client-side because the callback server must receive the redirect.
;(api as any).performOAuth = async (args: {
  sourceSlug: string
  sessionId?: string
  authRequestId?: string
  credentialScope?: 'workspace' | 'global' | 'workspace-override'
}): Promise<{ success: boolean; error?: string; email?: string }> => {
  let callbackServer: Awaited<ReturnType<typeof createCallbackServer>> | null = null
  let flowId: string | undefined
  let state: string | undefined

  try {
    // 1. Start local callback server to receive OAuth redirect
    callbackServer = await createCallbackServer({ appType: 'electron' })
    const callbackUrl = `${callbackServer.url}/callback`

    // 2. Ask server to prepare the flow (PKCE, auth URL, store in flow store)
    const startResult = await client.invoke('oauth:start', {
      sourceSlug: args.sourceSlug,
      callbackUrl,
      sessionId: args.sessionId,
      authRequestId: args.authRequestId,
      credentialScope: args.credentialScope,
    })
    flowId = startResult.flowId
    state = startResult.state
    if (!flowId || !state) {
      throw new Error('OAuth flow did not return its verification state.')
    }

    // 3. Open browser for user consent (local — must open on the user's machine, not remote server)
    await shell.openExternal(startResult.authUrl)

    // 4. Wait for OAuth provider to redirect to our callback server
    const callback = await callbackServer.promise

    // 5. Validate the one-time state nonce before accepting any callback data.
    const validated = validateOAuthCallback(callback, state)
    if ('error' in validated) {
      await client.invoke('oauth:cancel', { flowId, state })
      return { success: false, error: validated.error }
    }

    // 6. Send code to server for token exchange + credential storage
    const result = await client.invoke('oauth:complete', { flowId, code: validated.code, state })
    return { success: result.success, error: result.error, email: result.email }
  } catch (err) {
    // Clean up server-side flow on error
    if (flowId && state) {
      client.invoke('oauth:cancel', { flowId, state }).catch(() => {})
    }
    return {
      success: false,
      error: err instanceof Error ? err.message : 'OAuth flow failed',
    }
  } finally {
    callbackServer?.close()
  }
}

// ── startClaudeOAuth ─────────────────────────────────────────────────────
// Override the channel-map stub: the server now returns authUrl without opening
// the browser. We open it locally so it works in remote mode.
// Claude OAuth is two-step: browser opens → user copies code → pastes in UI.
;(api as any).startClaudeOAuth = async (): Promise<{
  success: boolean
  authUrl?: string
  error?: string
}> => {
  try {
    const result = await client.invoke('onboarding:startClaudeOAuth')
    if (result.success && result.authUrl) {
      await shell.openExternal(result.authUrl)
    }
    return result
  } catch (err) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Claude OAuth failed',
    }
  }
}

// ── performChatGptOAuth ──────────────────────────────────────────────────
// Same shape as performOAuth: callback server (port 1455) → chatgpt:startOAuth →
// browser → callback → chatgpt:completeOAuth.
// Overrides the startChatGptOAuth API method so the renderer call is unchanged.
;(api as any).startChatGptOAuth = async (
  connectionSlug: string,
): Promise<{ success: boolean; error?: string }> => {
  let callbackServer: Awaited<ReturnType<typeof createCallbackServer>> | null = null
  let flowId: string | undefined
  let state: string | undefined

  try {
    // 1. Start callback server on ChatGPT's fixed port with /auth/callback path
    callbackServer = await createCallbackServer({
      appType: 'electron',
      port: CHATGPT_OAUTH_CONFIG.CALLBACK_PORT,
      callbackPaths: ['/auth/callback'],
    })

    // 2. Ask server to prepare the flow (PKCE, auth URL, store pending flow)
    const startResult = await client.invoke('chatgpt:startOAuth', connectionSlug)
    flowId = startResult.flowId
    state = startResult.state

    // 3. Open browser for user consent
    await shell.openExternal(startResult.authUrl)

    // 4. Wait for OpenAI to redirect to our callback server
    const callback = await callbackServer.promise

    // 5. Check for errors from the provider
    if (callback.query.error) {
      const error = callback.query.error_description || callback.query.error
      await client.invoke('chatgpt:cancelOAuth', { state })
      return { success: false, error }
    }

    if (callback.query.state !== state) {
      await client.invoke('chatgpt:cancelOAuth', { state })
      return {
        success: false,
        error: `OAuth response did not belong to ${productVariant === 'artist-os' ? 'Artist OS' : 'Runner'}`,
      }
    }

    const code = callback.query.code
    if (!code) {
      await client.invoke('chatgpt:cancelOAuth', { state })
      return { success: false, error: 'No authorization code received' }
    }

    // 6. Send code to server for token exchange + credential storage
    const result = await client.invoke('chatgpt:completeOAuth', { flowId, code, state })
    return { success: result.success, error: result.error }
  } catch (err) {
    if (state) {
      client.invoke('chatgpt:cancelOAuth', { state }).catch(() => {})
    }
    return {
      success: false,
      error: err instanceof Error ? err.message : 'ChatGPT OAuth flow failed',
    }
  } finally {
    callbackServer?.close()
  }
}

// App lifecycle — direct IPC (not WS RPC) since it restarts the server itself
;(api as ElectronAPI).getLicenseState = () => ipcRenderer.invoke('__license:get-state')
;(api as ElectronAPI).activateLicense = (input: ArtistOSActivateInputV1) => ipcRenderer.invoke('__license:activate', input)
;(api as ElectronAPI).refreshLicense = () => ipcRenderer.invoke('__license:refresh')
;(api as ElectronAPI).deactivateLicense = () => ipcRenderer.invoke('__license:deactivate')
;(api as ElectronAPI).openLicenseLink = (kind) => ipcRenderer.invoke('__license:open-link', kind)
;(api as ElectronAPI).onLicenseStateChanged = (callback: (snapshot: ArtistOSLicenseSnapshotV1) => void) => {
  const handler = (_event: Electron.IpcRendererEvent, snapshot: ArtistOSLicenseSnapshotV1) => callback(snapshot)
  ipcRenderer.on('__license:state-changed', handler)
  return () => ipcRenderer.removeListener('__license:state-changed', handler)
}
;(api as ElectronAPI).onLicenseRequired = (callback: () => void) => {
  const handler = () => callback()
  ipcRenderer.on('__license:required', handler)
  return () => ipcRenderer.removeListener('__license:required', handler)
}
;(api as ElectronAPI).relaunchApp = () => ipcRenderer.invoke('app:relaunch')
;(api as ElectronAPI).onCampaignDeleted = (callback) => {
  const listener = (_event: unknown, data: { workspaceId: string; hqWorkspaceId: string }) => callback(data)
  ipcRenderer.on('campaign:deleted', listener)
  return () => ipcRenderer.removeListener('campaign:deleted', listener)
}
;(api as ElectronAPI).previewCampaignCleanup = (workspaceId: string) => ipcRenderer.invoke('campaign:cleanupPreview', workspaceId)
;(api as ElectronAPI).deleteCampaign = (workspaceId: string, previewToken: string) => ipcRenderer.invoke('campaign:delete', workspaceId, previewToken)
;(api as ElectronAPI).removeWorkspace = (workspaceId: string) => ipcRenderer.invoke('workspace:remove', workspaceId)
;(api as ElectronAPI).invokeOnServer = (url: string, token: string, channel: string, ...args: any[]) =>
  ipcRenderer.invoke('server:invokeOnServer', url, token, channel, ...args)
;(api as ElectronAPI).transferSessionToWorkspace = (sessionId: string, targetWorkspaceId: string, sessionIndex?: number, sessionCount?: number) =>
  ipcRenderer.invoke('session:transferToRemoteWorkspace', sessionId, targetWorkspaceId, sessionIndex, sessionCount)
;(api as ElectronAPI).onTransferProgress = (cb: (progress: { sessionIndex: number; sessionCount: number; chunkSent: number; chunkTotal: number }) => void) => {
  const handler = (_e: any, progress: { sessionIndex: number; sessionCount: number; chunkSent: number; chunkTotal: number }) => cb(progress)
  ipcRenderer.on('transfer:progress', handler)
  return () => { ipcRenderer.removeListener('transfer:progress', handler) }
}

// System warnings — expose env-based flags set during main process startup
// (preload-only: reads env var directly, no IPC round-trip needed)
;(api as ElectronAPI).getSystemWarnings = async () => ({
  vcredistMissing: process.env.CRAFT_VCREDIST_MISSING === '1',
  downloadUrl: process.env.CRAFT_VCREDIST_URL,
})

// i18n: sync language changes to main process (for native menus/dialogs)
;(api as ElectronAPI).changeLanguage = (lang: string) => ipcRenderer.invoke('i18n:changeLanguage', lang)
;(api as ElectronAPI).captureVisualElement = (rect) => ipcRenderer.invoke('__visual:capture-element', rect)
;(api as ElectronAPI).getArtistManagerVoiceProxyInfo = () => ipcRenderer.invoke('__artist-manager-voice:proxy-info')
;(api as ElectronAPI).artistManagerVoiceSettings = {
  get: () => ipcRenderer.invoke('__artist-manager-voice-settings:get'),
  update: settings => ipcRenderer.invoke('__artist-manager-voice-settings:update', settings),
}
;(api as ElectronAPI).artistManagerVoiceWork = {
  invoke: request => ipcRenderer.invoke('__artist-manager-voice-work:invoke', request),
  subscribe: request => ipcRenderer.invoke('__artist-manager-voice-work:subscribe', request),
  onEvent: callback => {
    const listener = (_event: Electron.IpcRendererEvent, value: Parameters<typeof callback>[0]) => callback(value)
    ipcRenderer.on('__artist-manager-voice-work:event', listener)
    return () => { ipcRenderer.removeListener('__artist-manager-voice-work:event', listener) }
  },
}
;(api as ElectronAPI).artistManagerVoiceFocus = {
  register: request => ipcRenderer.invoke('__artist-manager-voice-focus:register', request),
  startTurn: request => ipcRenderer.invoke('__artist-manager-voice-focus:turn', request),
  cancel: request => ipcRenderer.invoke('__artist-manager-voice-focus:cancel', request),
  stop: sessionId => ipcRenderer.invoke('__artist-manager-voice-focus:stop', sessionId),
  onEvent: callback => {
    const listener = (_event: Electron.IpcRendererEvent, value: Parameters<typeof callback>[0]) => callback(value)
    ipcRenderer.on('__artist-manager-voice-focus:event', listener)
    return () => { ipcRenderer.removeListener('__artist-manager-voice-focus:event', listener) }
  },
}
;(api as ElectronAPI).getArtistManagerVoiceProviderStatus = () => ipcRenderer.invoke('__artist-manager-voice:provider-status')
;(api as ElectronAPI).createArtistManagerVoiceAssemblyToken = () => ipcRenderer.invoke('__artist-manager-voice:assembly-token')
;(api as ElectronAPI).invokeArtistManagerMoonshine = (request) => ipcRenderer.invoke('__artist-manager-moonshine:invoke', request)
;(api as ElectronAPI).getChatDictationAvailability = () => ipcRenderer.invoke('__chat-dictation:availability')
;(api as ElectronAPI).requestChatDictationAccess = () => ipcRenderer.invoke('__chat-dictation:request-access')
;(api as ElectronAPI).transcribeChatDictation = (input) => ipcRenderer.invoke('__chat-dictation:transcribe', input)

// webUtils.getPathForFile: returns the absolute OS path of a File object obtained
// from <input type="file"> or OS drag-drop. Returns null for Files fabricated from
// Blobs (clipboard paste, web-drag) — those are content-only, no filesystem path.
;(api as ElectronAPI).getFilePath = (file: File) => {
  try {
    return webUtils.getPathForFile(file) || null
  } catch {
    return null
  }
}
;(api as ElectronAPI).lookupProsodyRhymes = (input) => ipcRenderer.invoke('prosody:lookup', input)

contextBridge.exposeInMainWorld('electronAPI', api)
