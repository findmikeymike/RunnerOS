# Recovery state — r2, 2026-09-12

Worktree /Users/michaelb.williams/RunnerOS/.worktrees/conversational-work-spec; branch codex/conversational-work-spec; HEAD d0b5bae3c. Original uncommitted specs preserved. User authorized implementation; no commit/merge/push or app relaunch authorized. No app process was relaunched, provider called, or microphone activated during implementation.

## Accepted

P1 T101/T102 and phase review: native admission contract proof plus actual SDK/WASM/worklet playback proof. T201 native implementation accepted independently; task identity/crash cuts, immutable voice tool cap, exact specialist focus selection and existing Command fallback verified. T202 SDK external assistant turns, durable delivery leases/acknowledgements, result queue, call integration and saved-output controls accepted independently. Evidence/T-201.md and T-202.md contain commands/counts/hashes and reviewer verdicts. Feature remains default off; candidate opt-in CRAFT_ARTIST_VOICE_WORK_BRIDGE=1 plus renderer/SDK capability handshake.

Final T202 review: host32pass173assertions; SDK/scheduler/combined playback19pass115assertions; upstream41contracts. Root combined voice regressions74pass421assertions. Electron/server TypeScript, Artist OS variant main/worker/renderer/preload builds, local asset copy and197-file SDK integrity passed. Actual wrapper source reconstructed from c348947 plus new cumulative conversational-work-sdk.patch; WASM unchanged; original upstream checkout preserved.

## Next required work

T203 is executable but cannot run until Michael permits candidate relaunch (S-APP) and fresh live provider/specialist readiness is checked (S-LIVE). Its packet describes the real draft + unrelated spoken exchange + saved-result announcement test and recovery checks. Existing canonical Electron binary is available; no candidate-local binary was downloaded. Do not launch implicitly or call completed fixture proof a live result.

G-P2-EXIT remains pending T203. P3 question/approval continuation and later certification are not implemented/accepted; do not claim the entire conversational bridge complete. Background execution remains in-process and does not auto-resume after a crash. All work remains uncommitted. Resume by checking this state, plan validity and source/build drift, then honoring the user's explicit launch decision.
